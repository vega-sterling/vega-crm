--
-- PostgreSQL database dump
--

\restrict cD93ZOM2yOJv4a66JlQvCLoqTahOKaZXFh2ih9bTVB5XZJxwz5v9DIUf4UlDoup

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActivitySource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ActivitySource" AS ENUM (
    'MANUAL',
    'GMAIL',
    'VOIP',
    'IMPORT'
);


--
-- Name: ActivityType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ActivityType" AS ENUM (
    'CALL',
    'EMAIL',
    'NOTE',
    'TASK',
    'MEETING'
);


--
-- Name: DealStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DealStatus" AS ENUM (
    'OPEN',
    'WON',
    'LOST'
);


--
-- Name: GlobalRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."GlobalRole" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'USER'
);


--
-- Name: TaskPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TaskPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


--
-- Name: TaskStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TaskStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activities (
    id text NOT NULL,
    type public."ActivityType" NOT NULL,
    "tenantId" text NOT NULL,
    "companyId" text NOT NULL,
    "contactId" text,
    "userId" text NOT NULL,
    subject text NOT NULL,
    description text,
    "callDirection" text,
    "callDuration" integer,
    "callOutcome" text,
    "emailFrom" text,
    "emailTo" text,
    "emailCc" text,
    "emailBody" text,
    source public."ActivitySource" DEFAULT 'MANUAL'::public."ActivitySource" NOT NULL,
    "externalId" text,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "dealId" text
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "userId" text NOT NULL,
    action text NOT NULL,
    entity text NOT NULL,
    "entityId" text NOT NULL,
    changes jsonb,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: booking_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_slots (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "dayOfWeek" integer NOT NULL,
    "startTime" text NOT NULL,
    "endTime" text NOT NULL,
    "durationMin" integer DEFAULT 30 NOT NULL,
    "bufferMin" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id text NOT NULL,
    "bookingSlotId" text NOT NULL,
    "slotId" text NOT NULL,
    "contactId" text,
    "contactName" text,
    "contactEmail" text,
    "contactPhone" text,
    "companyId" text,
    notes text,
    "scheduledAt" timestamp(3) without time zone,
    "startAt" timestamp(3) without time zone NOT NULL,
    "endAt" timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "googleEventId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_events (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "googleEventId" text,
    title text NOT NULL,
    description text,
    location text,
    "startAt" timestamp(3) without time zone NOT NULL,
    "endAt" timestamp(3) without time zone NOT NULL,
    attendees text[] DEFAULT ARRAY[]::text[],
    "companyId" text,
    "contactId" text,
    "isAllDay" boolean DEFAULT false NOT NULL,
    status text DEFAULT 'CONFIRMED'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    industry text,
    website text,
    phone text,
    email text,
    address text,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id text NOT NULL,
    "companyId" text NOT NULL,
    "tenantId" text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text,
    phone text,
    mobile text,
    title text,
    department text,
    notes text,
    tags text[] DEFAULT ARRAY[]::text[],
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: custom_properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_properties (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    entity text NOT NULL,
    key text NOT NULL,
    label text NOT NULL,
    "fieldType" text NOT NULL,
    options text[] DEFAULT ARRAY[]::text[],
    "isRequired" boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: custom_property_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_property_values (
    id text NOT NULL,
    "propertyId" text NOT NULL,
    "entityId" text NOT NULL,
    value text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: deals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deals (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    title text NOT NULL,
    description text,
    "companyId" text NOT NULL,
    "contactId" text,
    "stageId" text NOT NULL,
    value double precision DEFAULT 0 NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    probability integer DEFAULT 50 NOT NULL,
    "expectedCloseDate" timestamp(3) without time zone,
    "actualCloseDate" timestamp(3) without time zone,
    status public."DealStatus" DEFAULT 'OPEN'::public."DealStatus" NOT NULL,
    "lossReason" text,
    "leadSource" text,
    "assignedToId" text NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: email_campaign_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_campaign_recipients (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    "contactId" text,
    email text NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "openedAt" timestamp(3) without time zone,
    "clickedAt" timestamp(3) without time zone,
    "repliedAt" timestamp(3) without time zone,
    status text DEFAULT 'PENDING'::text NOT NULL
);


--
-- Name: email_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_campaigns (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    "templateId" text,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "audienceFilter" jsonb,
    "scheduledAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "totalSent" integer DEFAULT 0 NOT NULL,
    "totalOpened" integer DEFAULT 0 NOT NULL,
    "totalClicked" integer DEFAULT 0 NOT NULL,
    "totalReplied" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: email_clicks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_clicks (
    id text NOT NULL,
    "emailMessageId" text NOT NULL,
    url text NOT NULL,
    "clickedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "ipAddress" text,
    "userAgent" text
);


--
-- Name: email_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_messages (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "userId" text NOT NULL,
    "companyId" text,
    "contactId" text,
    "dealId" text,
    "threadId" text,
    "messageId" text,
    direction text NOT NULL,
    "fromEmail" text NOT NULL,
    "toEmails" text[],
    "ccEmails" text[] DEFAULT ARRAY[]::text[],
    subject text NOT NULL,
    "bodyText" text,
    "bodyHtml" text,
    "isRead" boolean DEFAULT false NOT NULL,
    "isReplied" boolean DEFAULT false NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "syncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: email_opens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_opens (
    id text NOT NULL,
    "emailMessageId" text NOT NULL,
    "openedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "ipAddress" text,
    "userAgent" text
);


--
-- Name: email_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_sequences (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_templates (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    category text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: lead_form_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_form_submissions (
    id text NOT NULL,
    "formId" text NOT NULL,
    data jsonb NOT NULL,
    "contactId" text,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: lead_forms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_forms (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    fields jsonb NOT NULL,
    "redirectUrl" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "webhookUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: lead_score_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_score_rules (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    event text NOT NULL,
    points integer NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "entityId" text,
    "entityType" text,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: pipeline_stages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pipeline_stages (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    color text DEFAULT '#8b8d98'::text NOT NULL,
    "position" integer NOT NULL,
    probability integer DEFAULT 0 NOT NULL,
    "isWonStage" boolean DEFAULT false NOT NULL,
    "isLostStage" boolean DEFAULT false NOT NULL,
    "isArchived" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: project_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_columns (
    id text NOT NULL,
    "projectId" text NOT NULL,
    name text NOT NULL,
    color text DEFAULT '#8b8d98'::text NOT NULL,
    "position" integer NOT NULL,
    "wipLimit" integer,
    "isDoneColumn" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: project_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_tasks (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "columnId" text NOT NULL,
    "tenantId" text NOT NULL,
    title text NOT NULL,
    description text,
    "position" integer NOT NULL,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "assignedToId" text,
    "createdById" text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    labels text[] DEFAULT ARRAY[]::text[],
    color text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    description text,
    color text DEFAULT '#c9a96e'::text NOT NULL,
    icon text,
    "isArchived" boolean DEFAULT false NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: quote_line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_line_items (
    id text NOT NULL,
    "quoteId" text NOT NULL,
    description text NOT NULL,
    quantity double precision DEFAULT 1 NOT NULL,
    "unitPrice" double precision DEFAULT 0 NOT NULL,
    total double precision DEFAULT 0 NOT NULL
);


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotes (
    id text NOT NULL,
    "dealId" text NOT NULL,
    "tenantId" text NOT NULL,
    number text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    subtotal double precision DEFAULT 0 NOT NULL,
    "taxRate" double precision DEFAULT 0 NOT NULL,
    "taxAmount" double precision DEFAULT 0 NOT NULL,
    total double precision DEFAULT 0 NOT NULL,
    notes text,
    "validUntil" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "acceptedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: sequence_enrollment_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sequence_enrollment_steps (
    id text NOT NULL,
    "enrollmentId" text NOT NULL,
    "stepId" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "scheduledFor" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "emailMessageId" text
);


--
-- Name: sequence_enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sequence_enrollments (
    id text NOT NULL,
    "sequenceId" text NOT NULL,
    "contactId" text NOT NULL,
    "tenantId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "enrolledAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


--
-- Name: sequence_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sequence_steps (
    id text NOT NULL,
    "sequenceId" text NOT NULL,
    "templateId" text,
    "stepNumber" integer NOT NULL,
    "delayDays" integer DEFAULT 0 NOT NULL,
    "sendTime" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: sms_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_messages (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "contactId" text,
    "userId" text,
    direction text NOT NULL,
    body text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "externalId" text,
    "fromNumber" text NOT NULL,
    "toNumber" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: subtasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subtasks (
    id text NOT NULL,
    "taskId" text NOT NULL,
    title text NOT NULL,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "position" integer NOT NULL,
    "assignedToId" text,
    "dueDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_comments (
    id text NOT NULL,
    "taskId" text NOT NULL,
    "tenantId" text NOT NULL,
    "userId" text NOT NULL,
    body text NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    "companyId" text NOT NULL,
    "contactId" text,
    title text NOT NULL,
    description text,
    status public."TaskStatus" DEFAULT 'PENDING'::public."TaskStatus" NOT NULL,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "assignedToId" text NOT NULL,
    "createdById" text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tenant_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_settings (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    "isEncrypted" boolean DEFAULT false NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "updatedBy" text
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: user_tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_tenants (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tenantId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    "passwordHash" text NOT NULL,
    "globalRole" public."GlobalRole" DEFAULT 'USER'::public."GlobalRole" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "totpSecret" text,
    "totpEnabled" boolean DEFAULT false NOT NULL,
    "totpBackupCodes" text[] DEFAULT ARRAY[]::text[],
    "lastLoginAt" timestamp(3) without time zone,
    "lastLoginIp" text,
    "failedLoginAttempts" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "googleAccessToken" text,
    "googleEmail" text,
    "googleRefreshToken" text,
    "googleScope" text,
    "googleTokenExpiry" timestamp(3) without time zone
);


--
-- Name: workflow_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_executions (
    id text NOT NULL,
    "workflowId" text NOT NULL,
    "entityId" text NOT NULL,
    "entityType" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    result jsonb,
    error text,
    "executedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflows (
    id text NOT NULL,
    "tenantId" text NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    trigger text NOT NULL,
    "triggerConfig" jsonb,
    conditions jsonb,
    actions jsonb NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activities (id, type, "tenantId", "companyId", "contactId", "userId", subject, description, "callDirection", "callDuration", "callOutcome", "emailFrom", "emailTo", "emailCc", "emailBody", source, "externalId", "scheduledAt", "completedAt", "createdAt", "updatedAt", "dealId") FROM stdin;
cmsfn02v6000001rvm2r5j9ud	NOTE	cmrxknens00009nph8q7kzo30	cmrxn66fv14nzkcm4yp0954mpij3apmjuw5yywpek56y	\N	cmrxknens00039nph8q7kzo30	Phase 2 test note	Testing @Bryan Paulk mention in the new Phase 2 ActivityCard component. This is a longer note to test the expand/collapse feature. AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA	\N	\N	\N	\N	\N	\N	\N	MANUAL	\N	\N	\N	2026-08-05 05:19:03.042	2026-08-05 05:19:03.042	\N
cmsfm4g8i000001nzflkt23ok	NOTE	cmrxkneb300009nph1q2bem5q	cmrxn66fv14nzkcm4yp0954mpij3apmjuw5yywpek56y	\N	fafc63fb-db10-49d4-b3ba-3f7974e464e1	Phase 1 deployment test	Testing inline note composer via API - deployed successfully	\N	\N	\N	\N	\N	\N	\N	MANUAL	\N	\N	\N	2026-08-05 04:54:27.378	2026-08-05 04:54:27.378	\N
cmrxzw7m054yw5r11bbjc0hvijljhotkp0wzmlzqeuf9	CALL	cmrxkneb300009nph1q2bem5q	cmrxhpibz0h9eccqpcyt2s2ukb653zqzaie3qdhn5z64	cmrxu8he7lbddkwwlg5h73agsmz30obgy9qc07z428bs	cmrxkneza00049nphloi87ri0	Voicemail left for Coby Brown at OzarksGo	Leon called Coby Brown at OzarksGo on Tuesday morning (Aug 4, 2026) and left a voicemail. Awaiting response.	OUTBOUND	\N	VOICEMAIL	\N	\N	\N	\N	MANUAL	\N	\N	2026-08-04 15:09:14	2026-08-04 15:09:14	2026-08-04 15:09:14	\N
cmrx2mc235mhugqtee2ovtgz06zreo0t0y8w0hc7mmnm	EMAIL	cmrxkneb300009nph1q2bem5q	cmrxig5tj7oixvzrk1kyiukzy9ektal2fzsml0toeciz	cmrxfi5ypnellqtt307ncnlj75x70d1tkqquthjrquyo	cmrxkneza00049nphloi87ri0	Follow-up email to U.S. Bank re: CyberSource/Global Payments IDs, vendor letter, online banking access	Leon sent a follow-up email to Peter, Liliana, and Anuja at U.S. Bank regarding:\n1. Adding CyberSource and Global Payments Company IDs to the MDU Solutions account ending in 5604\n2. A brief vendor letter confirming that a banking issue affected access to funds and payments\n3. Activating MDU Solutions' online banking access\nStatus: Awaiting response from U.S. Bank.	\N	\N	\N	leon.zetekoff@mdusolutions.com	peter@usbank.com, liliana@usbank.com, anuja@usbank.com	\N	\N	MANUAL	\N	\N	2026-08-04 15:09:14	2026-08-04 15:09:14	2026-08-04 15:09:14	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, "userId", action, entity, "entityId", changes, "ipAddress", "createdAt") FROM stdin;
\.


--
-- Data for Name: booking_slots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.booking_slots (id, "userId", "tenantId", "dayOfWeek", "startTime", "endTime", "durationMin", "bufferMin", "isActive", "createdAt") FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookings (id, "bookingSlotId", "slotId", "contactId", "contactName", "contactEmail", "contactPhone", "companyId", notes, "scheduledAt", "startAt", "endAt", status, "googleEventId", "createdAt") FROM stdin;
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_events (id, "userId", "tenantId", "googleEventId", title, description, location, "startAt", "endAt", attendees, "companyId", "contactId", "isAllDay", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, "tenantId", name, industry, website, phone, email, address, description, "isActive", "createdAt", "updatedAt") FROM stdin;
cmrxhpibz0h9eccqpcyt2s2ukb653zqzaie3qdhn5z64	cmrxkneb300009nph1q2bem5q	OzarksGo	Telecommunications / ISP	https://ozarksgo.com	\N	\N	\N	\N	t	2026-08-04 15:09:14	2026-08-04 15:09:14
cmrxig5tj7oixvzrk1kyiukzy9ektal2fzsml0toeciz	cmrxkneb300009nph1q2bem5q	U.S. Bank	Banking / Financial Services	\N	\N	\N	\N	\N	t	2026-08-04 15:09:14	2026-08-04 15:09:14
cmrxn66fv14nzkcm4yp0954mpij3apmjuw5yywpek56y	cmrxkneb300009nph1q2bem5q	Authorize.Net	Payment Processing	\N	\N	\N	\N	\N	t	2026-08-04 23:15:29	2026-08-04 23:15:29
cmrxx5w4zx7uhvd32dbgf1qju7cs6dg10b0q9e7yae6u	cmrxkneb300009nph1q2bem5q	NAPA	Telecommunications / ISP	\N	\N	\N	\N	\N	t	2026-08-04 23:15:29	2026-08-04 23:15:29
cmrxbclich0lrdbvw72texizpqw91rbcpoyteo9eykpg	cmrxkneb300009nph1q2bem5q	DOTmed	Medical Equipment Marketplace	\N	\N	\N	\N	\N	t	2026-08-04 23:15:29	2026-08-04 23:15:29
cmrxpyow8ae1bbnizqz93atchvs9v3wu2wrtunisji3d	cmrxkneb300009nph1q2bem5q	CoreSite	Data Center / Colocation	\N	\N	\N	\N	\N	t	2026-08-04 23:15:29	2026-08-04 23:15:29
cmrxknfb9000h9nphre1wz2hc	cmrxknebq00029nphxgtlo2sc	Retreat Partners LLC	Wellness / Retreats	\N	555-0300	hello@retrpartners.com	\N	Retreat venue partnership	f	2026-07-23 13:53:22.245	2026-08-05 04:38:57.643
cmrxknfax000d9nphbp3r2t25	cmrxkneb300009nph1q2bem5q	Test Property Management	Property Management	\N	555-0100	info@testprop.com	\N	Sample property management company for MDU demo	f	2026-07-23 13:53:22.233	2026-08-05 04:39:00.797
cmrxknfb6000f9nphsy2rofgu	cmrxknebk00019nph5p98uh1z	Wellness Dispensary	Retail / Wellness	\N	555-0200	contact@wellnessdisp.com	\N	Potential wholesale customer for Flying Mushroom	f	2026-07-23 13:53:22.242	2026-08-05 04:39:03.285
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, "companyId", "tenantId", "firstName", "lastName", email, phone, mobile, title, department, notes, tags, "isActive", "createdAt", "updatedAt") FROM stdin;
cmrxu8he7lbddkwwlg5h73agsmz30obgy9qc07z428bs	cmrxhpibz0h9eccqpcyt2s2ukb653zqzaie3qdhn5z64	cmrxkneb300009nph1q2bem5q	Coby	Brown	\N	\N	\N	\N	\N	\N	{}	t	2026-08-04 15:09:14	2026-08-04 15:09:14
cmrxfi5ypnellqtt307ncnlj75x70d1tkqquthjrquyo	cmrxig5tj7oixvzrk1kyiukzy9ektal2fzsml0toeciz	cmrxkneb300009nph1q2bem5q	Peter		\N	\N	\N	\N	\N	\N	{}	t	2026-08-04 15:09:14	2026-08-04 15:09:14
cmrxjbb4k115gnpg9aog54t3c1u7y6fh8p3g1etf3z87	cmrxig5tj7oixvzrk1kyiukzy9ektal2fzsml0toeciz	cmrxkneb300009nph1q2bem5q	Liliana		\N	\N	\N	\N	\N	\N	{}	t	2026-08-04 15:09:14	2026-08-04 15:09:14
cmrxftqu63ee9jreony4psjt0i222j825631brenlmji	cmrxig5tj7oixvzrk1kyiukzy9ektal2fzsml0toeciz	cmrxkneb300009nph1q2bem5q	Anuja		\N	\N	\N	\N	\N	\N	{}	t	2026-08-04 15:09:14	2026-08-04 15:09:14
cmrxknfbk000n9npho7zej3ot	cmrxknfb9000h9nphre1wz2hc	cmrxknebq00029nphxgtlo2sc	Michael	Brown	michael@retrpartners.com	555-0301	\N	Operations Director	\N	\N	{}	f	2026-07-23 13:53:22.256	2026-08-05 04:39:12.062
cmrxknfbi000l9nphbary2rvm	cmrxknfb6000f9nphsy2rofgu	cmrxknebk00019nph5p98uh1z	Sarah	Johnson	sarah@wellnessdisp.com	555-0201	\N	Buyer	\N	\N	{}	f	2026-07-23 13:53:22.254	2026-08-05 04:39:16.011
cmrxknfbc000j9nphy9zz4365	cmrxknfax000d9nphbp3r2t25	cmrxkneb300009nph1q2bem5q	John	Smith	john@testprop.com	555-0101	\N	Property Manager	\N	\N	{}	f	2026-07-23 13:53:22.248	2026-08-05 04:39:18.403
\.


--
-- Data for Name: custom_properties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_properties (id, "tenantId", entity, key, label, "fieldType", options, "isRequired", "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: custom_property_values; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_property_values (id, "propertyId", "entityId", value, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: deals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deals (id, "tenantId", title, description, "companyId", "contactId", "stageId", value, currency, probability, "expectedCloseDate", "actualCloseDate", status, "lossReason", "leadSource", "assignedToId", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: email_campaign_recipients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_campaign_recipients (id, "campaignId", "contactId", email, "sentAt", "openedAt", "clickedAt", "repliedAt", status) FROM stdin;
\.


--
-- Data for Name: email_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_campaigns (id, "tenantId", name, subject, body, "templateId", status, "audienceFilter", "scheduledAt", "sentAt", "totalSent", "totalOpened", "totalClicked", "totalReplied", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: email_clicks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_clicks (id, "emailMessageId", url, "clickedAt", "ipAddress", "userAgent") FROM stdin;
\.


--
-- Data for Name: email_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_messages (id, "tenantId", "userId", "companyId", "contactId", "dealId", "threadId", "messageId", direction, "fromEmail", "toEmails", "ccEmails", subject, "bodyText", "bodyHtml", "isRead", "isReplied", "sentAt", "receivedAt", "syncedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: email_opens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_opens (id, "emailMessageId", "openedAt", "ipAddress", "userAgent") FROM stdin;
\.


--
-- Data for Name: email_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_sequences (id, "tenantId", name, description, "isActive", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_templates (id, "tenantId", name, subject, body, category, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_form_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_form_submissions (id, "formId", data, "contactId", "ipAddress", "userAgent", "createdAt") FROM stdin;
\.


--
-- Data for Name: lead_forms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_forms (id, "tenantId", name, slug, fields, "redirectUrl", "isActive", "webhookUrl", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_score_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_score_rules (id, "tenantId", event, points, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, "userId", type, title, message, "entityId", "entityType", "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: pipeline_stages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pipeline_stages (id, "tenantId", name, color, "position", probability, "isWonStage", "isLostStage", "isArchived", "createdAt", "updatedAt") FROM stdin;
c2f03e5732ed4085acf1cb65a	cmrxkneb300009nph1q2bem5q	Lead	#8b8d98	0	10	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
cd572e3c3af5d5fb05856b040	cmrxkneb300009nph1q2bem5q	Qualified	#60a5fa	1	25	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
cc08fdddc8053965929870e36	cmrxkneb300009nph1q2bem5q	Proposal	#c9a96e	2	50	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c54f1a3ec48c1ffd03e06dfe6	cmrxkneb300009nph1q2bem5q	Negotiation	#f59e0b	3	75	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
cb004f52626ad2281e50f13d7	cmrxkneb300009nph1q2bem5q	Won	#4ade80	4	100	t	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
ccf10effe3aa993e65bb5c0c3	cmrxkneb300009nph1q2bem5q	Lost	#e57373	5	0	f	t	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c5d3d6cd6d3e435b9da9084fc	cmrxknebk00019nph5p98uh1z	Lead	#8b8d98	0	10	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
cd265cbd72ae94846b9aed4f1	cmrxknebk00019nph5p98uh1z	Qualified	#60a5fa	1	25	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
ce5ca51fb5c6f76c2d0615b2a	cmrxknebk00019nph5p98uh1z	Proposal	#c9a96e	2	50	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
cd2b18d14525926c02d3713fa	cmrxknebk00019nph5p98uh1z	Negotiation	#f59e0b	3	75	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c8f8e6b73c3901c11c4667e47	cmrxknebk00019nph5p98uh1z	Won	#4ade80	4	100	t	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c7306309451c473b6f5382f12	cmrxknebk00019nph5p98uh1z	Lost	#e57373	5	0	f	t	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
cf5c9370812165186ec8eeca1	cmrxknebq00029nphxgtlo2sc	Lead	#8b8d98	0	10	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
cc03ac6de5c022b0bc48b9e2d	cmrxknebq00029nphxgtlo2sc	Qualified	#60a5fa	1	25	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c6a6049628355f150c363366f	cmrxknebq00029nphxgtlo2sc	Proposal	#c9a96e	2	50	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c7720c4de47756d51c752b5df	cmrxknebq00029nphxgtlo2sc	Negotiation	#f59e0b	3	75	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c16c415263e5e763b2240de06	cmrxknebq00029nphxgtlo2sc	Won	#4ade80	4	100	t	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c9c05e8380507d4c38f16531b	cmrxknebq00029nphxgtlo2sc	Lost	#e57373	5	0	f	t	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c8f350b447710f1ae84f1a834	cmrxshared0000vegahq01	Lead	#8b8d98	0	10	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c98d51f7739fb1ba5adddee82	cmrxshared0000vegahq01	Qualified	#60a5fa	1	25	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c6cd249cf84e224c6ebb86a4a	cmrxshared0000vegahq01	Proposal	#c9a96e	2	50	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
cea8c2cb6593843bd9ebf6bc2	cmrxshared0000vegahq01	Negotiation	#f59e0b	3	75	f	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c412776255b1774167bbffc45	cmrxshared0000vegahq01	Won	#4ade80	4	100	t	f	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
c107956a571e7a4d1fbb7ece8	cmrxshared0000vegahq01	Lost	#e57373	5	0	f	t	f	2026-08-03 04:16:43.468	2026-08-03 04:16:43.468
\.


--
-- Data for Name: project_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_columns (id, "projectId", name, color, "position", "wipLimit", "isDoneColumn", "createdAt", "updatedAt") FROM stdin;
c000000000000000000000000019fc5301d0fk6avsskqkhk8k4n2	c000000000000000000000000019fc5301d0e500psqpmmogpuc6k	To Do	#60a5fa	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f90j200e88vndqiiu	c000000000000000000000000019fc5301d0e500psqpmmogpuc6k	In Progress	#c9a96e	1	5	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0feiiv2f66y2cwcuvq	c000000000000000000000000019fc5301d0e500psqpmmogpuc6k	Done	#4ade80	2	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f05au0eqq3fk1a307	c000000000000000000000000019fc5301d0fqmpdv8fdp4w8btlx	To Do	#60a5fa	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fsitjbsa2tcbr5ktl	c000000000000000000000000019fc5301d0fqmpdv8fdp4w8btlx	In Progress	#c9a96e	1	5	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f6gm6zzo573whi568	c000000000000000000000000019fc5301d0fqmpdv8fdp4w8btlx	Done	#4ade80	2	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fp3lpiexk9b83jhdv	c000000000000000000000000019fc5301d0f69xln34llbbp2423	Active Projects	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	c000000000000000000000000019fc5301d0f69xln34llbbp2423	Open Tasks	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fh52u5p9cc54ddgtc	c000000000000000000000000019fc5301d0f69xln34llbbp2423	Blockers	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f7g71c0yz18qx3ntf	c000000000000000000000000019fc5301d0f69xln34llbbp2423	Waiting Items	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	c000000000000000000000000019fc5301d0f69xln34llbbp2423	Human-Required Items	#8b8d98	4	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fw919l87s4ci1fdm8	c000000000000000000000000019fc5301d0f69xln34llbbp2423	Next Actions	#8b8d98	5	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f6yu4k8k99jn6z034	c000000000000000000000000019fc5301d0f69xln34llbbp2423	Done	#4ade80	6	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d1031u2zty3obpoipng	c000000000000000000000000019fc5301d109f6mv6erd07i4stw	To Do	#60a5fa	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10sin7e45izv3b78l9	c000000000000000000000000019fc5301d109f6mv6erd07i4stw	In Progress	#c9a96e	1	5	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10o2be4yhxmioo1kji	c000000000000000000000000019fc5301d109f6mv6erd07i4stw	Done	#4ade80	2	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	To Do	#60a5fa	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10y496lm971awqqv48	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	In Progress	#c9a96e	1	5	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d1077bqxaflj7gv8hzb	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	Done	#4ade80	2	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10zcew7fck2p6ljuuq	c000000000000000000000000019fc5301d10obkjt6smotqial2c	Active Projects	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10h3t1lilzohm37g56	c000000000000000000000000019fc5301d10obkjt6smotqial2c	Open Tasks	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10gp2oz2v99dwz4wx2	c000000000000000000000000019fc5301d10obkjt6smotqial2c	Blockers	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10t5d4cfalv4jczfki	c000000000000000000000000019fc5301d10obkjt6smotqial2c	Waiting Items	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10s7hiyrmw56sos0vb	c000000000000000000000000019fc5301d10obkjt6smotqial2c	Human-Required Items	#8b8d98	4	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10y10abrtclkc2npjj	c000000000000000000000000019fc5301d10obkjt6smotqial2c	Next Actions	#8b8d98	5	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10ovk9mrl254u06yw7	c000000000000000000000000019fc5301d10obkjt6smotqial2c	Done	#4ade80	6	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fipoj97pxci7l32yx	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	Open Tasks	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:04:55.587
c000000000000000000000000019fc5301d0fjwr7yzvbusps4zfz	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	Next Actions	#8b8d98	5	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:04:55.59
c000000000000000000000000019fc5301d0f12zcqv4ryvtr8ate	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	Open Tasks	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:06:16.956
c000000000000000000000000019fc5301d0fz1zbhqiay9luwgox	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	Next Actions	#8b8d98	5	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:06:16.958
c000000000000000000000000019fc5301d0fkqt28lip120ck6z3	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	Blockers	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:06:16.958
c000000000000000000000000019fc5301d0fhozpi0821efwr4wj	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	Active Projects	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:06:16.957
c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	Human-Required Items	#8b8d98	4	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:06:16.96
c000000000000000000000000019fc5301d0flcp2tivc33zrat1w	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	Done	#4ade80	6	\N	t	2026-08-03 01:14:59.1	2026-08-03 04:06:16.96
c000000000000000000000000019fc5301d0f3y55p3if8451mfn2	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	Waiting Items	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:06:16.961
c000000000000000000000000019fc5301d10urst31v0xa68il8b	c000000000000000000000000019fc5301d10kp51odxb096lgtfq	Active Projects	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10631afrfnxxjanphi	c000000000000000000000000019fc5301d10kp51odxb096lgtfq	Open Tasks	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10eogkqzezulap4vn0	c000000000000000000000000019fc5301d10kp51odxb096lgtfq	Blockers	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10deziydrip216gimb	c000000000000000000000000019fc5301d10kp51odxb096lgtfq	Waiting Items	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d104mixaqnoyeav2lh0	c000000000000000000000000019fc5301d10kp51odxb096lgtfq	Human-Required Items	#8b8d98	4	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10vtscvov4wqu8pe5v	c000000000000000000000000019fc5301d10kp51odxb096lgtfq	Next Actions	#8b8d98	5	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10c0bobcaqvyq48gxc	c000000000000000000000000019fc5301d10kp51odxb096lgtfq	Done	#4ade80	6	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d109f5q1k951zr78zj3	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	MDU Solutions	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10jbzqvb4ucfn6f9cm	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	Flying Mushroom	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10kcpjypta8twgiy8d	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	Velanra Healing Center	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d105hgqrlftb165s18n	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	Anra Foundation	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10p9ezvv08mdeec9mm	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	Vela Institute	#8b8d98	4	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10lcxso56u6mnqh8mj	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	Done	#4ade80	5	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10agl34wtnwx3mkgfg	c000000000000000000000000019fc5301d10cg17aougccqenfdd	Active Customers	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10md8m6i16fvndvfxx	c000000000000000000000000019fc5301d10cg17aougccqenfdd	Leads	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10zcynyt31kw2nzc87	c000000000000000000000000019fc5301d10cg17aougccqenfdd	Contacted	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10m1arxhfe6z0itomo	c000000000000000000000000019fc5301d10cg17aougccqenfdd	Demo Scheduled	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10q9rlx1bw0e49yz1j	c000000000000000000000000019fc5301d10cg17aougccqenfdd	Demo Complete	#8b8d98	4	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10ewbe2sn3fq9uhsef	c000000000000000000000000019fc5301d10cg17aougccqenfdd	Proposal Sent	#8b8d98	5	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10f2ry3npqyg26nbdz	c000000000000000000000000019fc5301d10cg17aougccqenfdd	Negotiating	#8b8d98	6	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10s7rslnbpwxhq931w	c000000000000000000000000019fc5301d10cg17aougccqenfdd	Won	#8b8d98	7	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10cyy9ixdgzv66ow5m	c000000000000000000000000019fc5301d10cg17aougccqenfdd	Lost	#8b8d98	8	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d104gmm67ngcl5j4rae	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	Leads	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10s3x9yi94nrfufvzh	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	Leads	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10cetwe7ya74z8jz17	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	Contacted	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10d0q0oricqd9ooinb	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	Follow-Up	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10ocxvj6uhcl46vd5h	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	Due Diligence	#8b8d98	4	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d1056sot65fz5df7smm	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	Proposal/Pricing	#8b8d98	5	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10kgfp6wifbd3tblm6	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	Deferred/Closed	#8b8d98	6	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d11qulb7g8rue0oiofx	c000000000000000000000000019fc5301d119k5eya8hcwd35nka	Leads	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d1145quivxf77cbrgxg	c000000000000000000000000019fc5301d119k5eya8hcwd35nka	Done	#4ade80	1	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	Leads	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d110qs7oqozy72exrfr	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	Done	#4ade80	1	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	c000000000000000000000000019fc5301d1157efats39jo7day2	Leads	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d11diuse1aou66hopb9	c000000000000000000000000019fc5301d1157efats39jo7day2	Done	#4ade80	1	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	Leads	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d13fi60ug8n0atlzkx9	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	Done	#4ade80	1	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	Leads	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d1448gpbzg4qca9cxu1	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	Contacted	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d14epz0yiy5p8yqrr87	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	Follow-Up	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d14loqoc5zklt5mq0bj	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	Deferred/Closed	#8b8d98	3	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15eiouvp8gyjv7pqni	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	Leads	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d156gas8j6pfh3ckvud	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	Contacted	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15s54sfvdvb5qfwq1q	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	Follow-Up	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15mfhzyk2y2ado5ykk	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	Demo Scheduled	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15ye6xsv2wehsrowea	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	Demo Completed	#8b8d98	4	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15bhcvib79ibu5iqna	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	Pricing/Proposal	#8b8d98	5	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15vi3oeqyixxh7gttp	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	Won	#8b8d98	6	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15o5hlz1ppxtrbkfyo	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	Deferred/Closed	#8b8d98	7	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d154w33q41jfozzmylj	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	Integrations	#8b8d98	8	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15hgn20xjgqbvfqwxt	c000000000000000000000000019fc5301d1541ek24xvly4pxv5z	Prospects	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15f3wv5eexd2dlyonj	c000000000000000000000000019fc5301d1541ek24xvly4pxv5z	Information Sent	#8b8d98	1	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d153nuf734f3pqhm7xt	c000000000000000000000000019fc5301d1541ek24xvly4pxv5z	Follow-Up	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15zzxsi74ut1vfxmh1	c000000000000000000000000019fc5301d1541ek24xvly4pxv5z	Active Referral Partners	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15dyrswgonktocpcnz	c000000000000000000000000019fc5301d1541ek24xvly4pxv5z	Deferred/Closed	#8b8d98	4	\N	t	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d151z5qszf8r1le60ll	c000000000000000000000000019fc5301d1541ek24xvly4pxv5z	Information Sent	#8b8d98	5	\N	f	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f8tz5ovjt4w4l0b22	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	Blockers	#8b8d98	2	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:04:55.588
c000000000000000000000000019fc5301d0f4oh7cljxyrj5t98m	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	Waiting Items	#8b8d98	3	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:04:55.589
c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	Active Projects	#8b8d98	0	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:04:55.59
c000000000000000000000000019fc5301d0fxd73lnhu6pigkjof	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	Done	#4ade80	6	\N	t	2026-08-03 01:14:59.1	2026-08-03 04:04:55.59
c000000000000000000000000019fc5301d0f6r6flrxzgbjp9idv	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	Human-Required Items	#8b8d98	4	\N	f	2026-08-03 01:14:59.1	2026-08-03 04:04:55.59
\.


--
-- Data for Name: project_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_tasks (id, "projectId", "columnId", "tenantId", title, description, "position", priority, "assignedToId", "createdById", "dueDate", "completedAt", labels, color, "createdAt", "updatedAt") FROM stdin;
c000000000000000000000000019fc5301d0fthu6putpmyq5v5tm	c000000000000000000000000019fc5301d0e500psqpmmogpuc6k	c000000000000000000000000019fc5301d0fk6avsskqkhk8k4n2	cmrxshared0000vegahq01	Enable xAI API key for Hermes — add API key from console.x.ai to unlock Grok models + X search	\N	0	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{Research,[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fq53njf9xci5hbg1r	c000000000000000000000000019fc5301d0fqmpdv8fdp4w8btlx	c000000000000000000000000019fc5301d0f05au0eqq3fk1a307	cmrxshared0000vegahq01	Save ONRA Foundation messaging set for reference. Includes: Elevator pitch: "The ONRA Foundation removes barriers to care for veterans and first responders, funding therapies and support that help people access help, heal, and grow." Website intro: "ONRA helps veterans and first responders access care by funding therapies and support programs that meet people where they are and help them move forward." Donor message: "Your support removes financial barriers and makes effective care possible for 	\N	3	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f2ttnbtx13dol66oi	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Clean downloads folder	\N	0	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
78799206-e09a-4541-98c7-7f03f5638460	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fz1zbhqiay9luwgox	cmrxkneb300009nph1q2bem5q	Update Steve Chatman bandwidth quote spreadsheet with additional info received Friday	Update Steve Chatman’s bandwidth quote spreadsheet with the additional information received Friday afternoon. Keep Steve’s quotes separate from the Cogent MDU prospect project — this is a completely separate workstream.	0	MEDIUM	cmrxkneza00049nphloi87ri0	fafc63fb-db10-49d4-b3ba-3f7974e464e1	2026-08-04 00:00:00	\N	{Bandwidth,Steve-Chatman,Quotes}	\N	2026-08-03 20:32:17.644	2026-08-03 20:32:17.644
c000000000000000000000000019fc5301d0fsisgj9h9p2uhtrly	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	followup with coby ozarksgo	Company: OzarksGo | Contact: Coby Brown\n\nLeon called Coby Brown at OzarksGo on Tuesday morning (Aug 4, 2026) and left a voicemail. Awaiting response.\n\nActivity ID: cmrxzw7m054yw5r11bbjc0hvijljhotkp0wzmlzqeuf9	16	MEDIUM	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-05 00:00:00	\N	{Urgent,[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-04 15:09:14
c000000000000000000000000019fc5301d0fk9mru9v6vn2tak9n	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Set up Flying Mushroom shipping strategy\n\nWHAT I NEED FROM YOU (pick one option):\n→ Choose your shipping platform (recommendation below)\n→ Confirm shipping zones (US-only to start, or international?)\n→ Confirm packaging approach (insulated + cold packs for perishable, or dry goods only at launch?)\n\nRECOMMENDED PLATFORM: Pirate Ship\n• No monthly fees, no per-label markup\n• Cheapest USPS Priority Mail Cubic rates (best for small dense packages)\n• UPS Ground access at commercial rates\n• Free Shopif	\N	0	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f50afhvsebqaciop0	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Build Flying Mushroom pricing strategy (WAITING ON INPUTS)\n\nSTATUS: AI-QUEUED — I will execute this once you provide the data below.\n\nWHAT I NEED FROM YOU:\n→ Ingredient/substrate cost per unit (from task #2)\n→ Equipment amortization per batch (from task #3)\n→ Packaging cost per unit (bags, labels, boxes)\n→ Shipping cost per unit (from task #7 — Pirate Ship rates)\n→ Your desired margin per product (or target margin %)\n→ Any formula you already use (e.g. cost × 3, cost + $X, keystone pricing)\n→ Co	\N	1	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f21vgxp3ojrf5mws8	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Finish Flying Mushroom Shopify store setup & launch\n\nSTATUS: AI-QUEUED — I will execute this, but some steps need your input.\n\nWHAT I NEED FROM YOU:\n-> Confirm Shopify plan (Basic $39/mo is fine to start)\n-> Confirm domain is shop.flyingmushroom.com (already connected?)\n-> Confirm payment processor (Shopify Payments, Stripe, PayPal?)\n-> Product photos from task #6 (needed before store goes live)\n-> Pricing data from task #8 (needed before store goes live)\n\nWHAT I'LL DO:\n-> Complete Shopify theme	\N	2	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fjk0zwato7mm6b9dp	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Build Flying Mushroom inventory & stock management system\n\nSTATUS: AI-QUEUED — I will build this once product catalog exists.\n\nWHAT I NEED FROM YOU:\n-> Product list from task #1 (what products are we tracking?)\n-> Current stock levels (if any existing inventory)\n-> Batch tracking needs (do you track by grow batch/harvest date?)\n\nWHAT I'LL DO:\n-> Build inventory tracking spreadsheet (Google Sheets template)\n  - Per-product stock levels\n  - Batch/harvest date tracking\n  - Substrate batch to yield 	\N	3	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fizmjuiu9lj6y51rh	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Decide Flying Mushroom sales channels beyond Shopify\n\nWHAT I NEED FROM YOU:\n-> Which channels do you want to pursue?\n  - Farmers markets (which ones? Denver area?)\n  - Local restaurants (do you have relationships already?)\n  - Co-ops / natural food stores (which ones?)\n  - Wholesale / distribution (regional?)\n  - CSA / subscription boxes (weekly delivery?)\n-> Which channels are launch vs. later phase?\n-> Do you have any existing customer base to migrate?\n\nWHAT I'LL DO NEXT (once you decide):\n-> 	\N	4	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f4ucj9vxksydpb0cy	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Get Flying Mushroom product liability insurance\n\nSTATUS: Only remaining legal item. LLC, EIN, sales tax license, bank account all done.\n\nWHAT YOU NEED TO DO:\n-> Go to [Product Liability Insurance](https://www.nextinsurance.com/product-liability-insurance/)\n-> Click "Get a quote" or "Start a quote"\n-> Answer questions about your business:\n   - Business type: Retail / E-commerce\n   - Products sold: Mycology and agricultural supplies (substrates, cultures, grow kits, equipment)\n   - Business addres	\N	5	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f2qhirwqsemlifbjz	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Set up Flying Mushroom accounting & bookkeeping\n\nSTATUS: AI-QUEUED — I will build the system, you approve.\n\nWHAT I NEED FROM YOU:\n-> Do you already use accounting software? (QuickBooks, Wave, FreshBooks?)\n-> Do you have a business bank account separate from personal?\n-> Approximate monthly transaction volume (rough estimate is fine)\n\nWHAT I'LL DO:\n-> Set up chart of accounts (COGS, revenue, supplies, shipping, marketing)\n-> Build expense tracking system (categorized receipts, monthly close)\n-> S	\N	6	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fhx9ue9rbmmdk7r8d	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Build Flying Mushroom wholesale & B2B strategy\n\nSTATUS: AI-QUEUED — I will build the framework, you approve and make connections.\n\nWHAT I NEED FROM YOU:\n-> Any restaurant relationships you already have? (names)\n-> Target wholesale accounts (types: restaurants, co-ops, grocery stores?)\n-> Minimum order quantities for wholesale (your preference)\n-> Wholesale discount off retail (standard is 50%, you can go 40-60%)\n\nWHAT I'LL DO:\n-> Build wholesale pricing sheet (from task #8 pricing data)\n-> Creat	\N	7	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fsbifdy23626j5uuh	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Set up Flying Mushroom analytics & KPI dashboard\n\nSTATUS: AI-QUEUED — I will build this once Shopify store is live.\n\nWHAT I NEED FROM YOU:\n-> Google account to use for Analytics (or use existing?)\n-> Any specific metrics you care about most? (revenue, conversion rate, AOV?)\n\nWHAT I'LL DO:\n-> Set up Google Analytics 4 (GA4) on Shopify store\n-> Configure Shopify conversion tracking (purchases, add-to-cart, checkout)\n-> Set up Google Search Console (monitor search rankings)\n-> Build KPI dashboard (	\N	8	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10uqdr60071a1hfeil	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	cmrxknebq00029nphxgtlo2sc	[VEL] Engage medical governance lead to review medical clearance process, prescriber relationship, and CPOM-sensitive authority boundaries	\N	4	URGENT	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10wcfmm9jb0aompfsj	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	cmrxknebq00029nphxgtlo2sc	[VEL] Review and approve decision-rights matrix with Colorado counsel before operationalization	\N	7	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10nwjk8drb0ft2ffwk	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	cmrxknebq00029nphxgtlo2sc	[VEL] Schedule leadership review of Charter (VEL-CHR-001 v0.2) with Bryan for final approval before professional review routing	\N	8	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10u4snikwx6rato929	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Complete site selection for first Colorado location using VEL-CHK-GRW-001 New Site Readiness Gate (16 domains)	\N	5	MEDIUM	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f0okyi120kzz6r1mq	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Get U.S. Bank online banking operational	Company: U.S. Bank | Contacts: Peter, Liliana, Anuja\n\nVendor letter follow-up CLOSED — Bryan directed not to request another letter.\n\nRemaining items:\n1. Confirm CyberSource and Global Payments Company IDs added to account ending in 5604\n2. Activate MDU Solutions' online banking access\n\nStatus: Awaiting response.	14	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-31 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-04 23:15:29
264c9b52-681f-4da6-8a9a-d5e7c9121afb	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Remove Charles’s SSH keys from every system and authorized-key location	Remove all of Charles’s SSH keys from every system and authorized-key location. Verify the keys are no longer active anywhere and report completion. This is part of the BOP data cleanup — Charles was intentionally removed from BOP.	0	HIGH	cmrxknfam00099nphr69n8u1j	fafc63fb-db10-49d4-b3ba-3f7974e464e1	\N	\N	{Security,SSH,BOP-Cleanup,Urgent}	\N	2026-08-03 19:56:20.33	2026-08-03 19:56:20.33
c000000000000000000000000019fc5301d10liscv3m3g7tri7c0	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Enable xAI API key for Hermes — add API key from console.x.ai to unlock Grok models + X search	\N	1	LOW	\N	cmrxknens00039nph8q7kzo30	\N	\N	{Research}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10hl4wjmov7wcngvcv	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Define workflow for Anra Foundation (intake, eligibility, approval, and funding process) in a donor-friendly way	\N	2	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d109ea1dl21v2bszr2c	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Draft qualified provider policy for Anra Foundation using the agreed outline (purpose, scope, qualification criteria, application/review, client choice and referrals, funding rules, documentation/auditing, conflicts of interest, legal review).	\N	3	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10ppukitgyqeuwsfh8	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Store and refine warm donor inquiry email for Anra Foundation; use current draft as baseline and place final in shared drive (AI.VEL.Files/Anra Foundation) when available.	\N	4	MEDIUM	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10rgxp5eg3bebhy9a8	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Save Anra Foundation taglines and motto for reuse later: “Access with dignity. Choice with care.” plus taglines “Access. Choice. Care.” and “Funding care with dignity.” Add to concept and website copy when drafting.	\N	5	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d105xssbueq4rcfmqtb	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Draft and save reusable Anra Foundation mission statement and short About paragraph for website and donor materials. Align with messaging standard: independent nonprofit, client choice from qualified providers, transparent governance, and access for those who serve and underserved individuals with financial need.	\N	6	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10yjlqpr7zq8ohprfw	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Create formal and warm positioning copy for Vela Institute, including purpose, who it's for, positioning lines, and a short tagline. Save both versions for reuse and later move into a dedicated Vela Institute project once created.	\N	7	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10nxsif8ledjbdlryc	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Create formal and warm positioning for Vela Institute, including purpose, audience, positioning lines, tagline, and curriculum outline/checklist; add notes for retrieval keywords: curriculum, outline. Move to dedicated Vela Institute project once created.	\N	8	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d100hjqtgszmg0vmxug	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Create website-ready copy pack for Anra Foundation: motto and taglines; mission; About; website subhead; What we do section; donor call to action; warm donor inquiry email. Include client choice, qualified provider list, independence, and legal review notes. Place final in shared drive when available.	\N	9	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10pf8qpeio2p9rtcg3	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Create governance and intake starter kit for Anra Foundation: define roles and grant approvals, provider review responsibilities, conflicts handling, plus intake form and eligibility guidelines. Note to review with nonprofit counsel before go-live.	\N	10	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d103mci9jgcb3v9xnol	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Create consulting engagement template for Vela Institute to support healing center setup: phases, deliverables, timelines, SOP/documentation support, site selection support, regulatory readiness steps, and handoff. Include note for legal/regulatory review.	\N	11	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10h0rip1g5aybl0dz9	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	Move and consolidate Anra Foundation website copy currently saved in a comment on a related Velanra legal review task into the Anra Foundation website copy pack task. Ensure the copy pack is the single source of truth, and remove or update the misplaced comment if appropriate.	\N	12	HIGH	\N	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
093facbd-255e-47ff-aea5-ef932ab084f8	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	c000000000000000000000000019fc5301d15o5hlz1ppxtrbkfyo	cmrxkneb300009nph1q2bem5q	Tim Cullen / Colorado Harvest — Deferred/Nurture	Tim Cullen replied that he is no longer interested at this time. Moved to Deferred/Nurture for possible future follow-up. Contact history and information preserved in SP360 CRM workbook. No immediate outreach required.	0	MEDIUM	cmrxkneza00049nphloi87ri0	fafc63fb-db10-49d4-b3ba-3f7974e464e1	\N	\N	{SP360,Deferred,Not-Interested}	\N	2026-08-03 19:46:33.275	2026-08-03 19:46:33.275
de2f2bdf-b60b-44af-8fcb-9b723287b053	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Test updated SuperAdmin account — including username shorter than 6 characters	Test the updated SuperAdmin account. Specifically test handling of a username shorter than six characters. Report any validation, permission, or data-retention issues.	0	HIGH	cmrxknfam00099nphr69n8u1j	fafc63fb-db10-49d4-b3ba-3f7974e464e1	\N	\N	{Urgent,SuperAdmin,Testing}	\N	2026-08-03 19:46:33.38	2026-08-03 19:46:33.38
d4bc7d8e-520b-44f9-9ce2-453e3a62b8e3	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Test deleting and renaming a building	Test the building delete and rename functionality in the SuperAdmin panel. Report any validation, permission, or data-retention issues.	0	HIGH	cmrxknfam00099nphr69n8u1j	fafc63fb-db10-49d4-b3ba-3f7974e464e1	\N	\N	{Urgent,SuperAdmin,Testing}	\N	2026-08-03 19:46:33.477	2026-08-03 19:46:33.477
f0f787bd-1e8e-4423-89dc-9ade749d7248	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0flcp2tivc33zrat1w	cmrxkneb300009nph1q2bem5q	BOP data cleanup — removed Charles and Charisse + selected CVG contacts	Leon removed Charles and Charisse from BOP, along with selected CVG contacts. This is intentional data cleanup. Do not restore or reimport those records.	0	MEDIUM	cmrxkneza00049nphloi87ri0	fafc63fb-db10-49d4-b3ba-3f7974e464e1	\N	2026-08-03 19:46:33.574	{BOP,Data-Cleanup,Intentional}	\N	2026-08-03 19:46:33.574	2026-08-03 19:46:33.574
fc72bf9d-c2b9-4aba-834a-2c3e97e4cabd	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fz1zbhqiay9luwgox	cmrxkneb300009nph1q2bem5q	Reconcile outstanding accounts in BOP	Reconcile the outstanding accounts in BOP. Track in Vega CRM only — do not create or update Todoist tasks.	0	HIGH	cmrxkneza00049nphloi87ri0	fafc63fb-db10-49d4-b3ba-3f7974e464e1	2026-08-04 00:00:00	\N	{BOP,Reconcile,Urgent}	\N	2026-08-03 19:46:33.671	2026-08-03 19:46:33.671
8b32ea09-43f2-4269-be51-0dc440666283	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Test Dutchie integration with digital-signage system	Bob completed the Dutchie integration and created an emulator. Now needs to be tested with our digital-signage system.	0	HIGH	cmrxknfam00099nphr69n8u1j	fafc63fb-db10-49d4-b3ba-3f7974e464e1	\N	\N	{Dutchie,Testing,SP360}	\N	2026-08-03 19:46:33.768	2026-08-03 19:46:33.768
940d40cb-1612-4131-a6bc-cb341e2cec05	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0flcp2tivc33zrat1w	cmrxkneb300009nph1q2bem5q	BP confirmed: Begin using new Vega CRM for all task tracking	Effective 2026-08-03: BP confirmed we should begin using the new Vega CRM. Credentials are available. Do not create, update, move, close, comment on, or change due dates for any Todoist tasks. Use Vega CRM for all task, activity, follow-up, and status tracking.	0	MEDIUM	cmrxkneza00049nphloi87ri0	fafc63fb-db10-49d4-b3ba-3f7974e464e1	\N	2026-08-03 19:46:33.865	{Policy,Vega-CRM,BP-Directive}	\N	2026-08-03 19:46:33.865	2026-08-03 19:46:33.865
c000000000000000000000000019fc5301d0fvq1hi4kgent6tgrf	c000000000000000000000000019fc5301d0fqmpdv8fdp4w8btlx	c000000000000000000000000019fc5301d0f05au0eqq3fk1a307	cmrxshared0000vegahq01	repost linkedin and FB MDUS/Signage posts	\N	0	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-06-19 00:00:00	\N	{[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f6r6hlovmuxjjzyt7	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fz1zbhqiay9luwgox	cmrxkneb300009nph1q2bem5q	Digital signage SaaS pricing details — need current pricing for done-for-you programming + actual screen development	\N	0	URGENT	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f4q3gfnsoe73rnigw	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	cmrxknebq00029nphxgtlo2sc	PTSD - Who We Serve	\N	0	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0ftx8ytxlblnoy99cj	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f6r6flrxzgbjp9idv	cmrxknebk00019nph5p98uh1z	take pictures of samples received and ship back	\N	0	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fssd8cbcro2v1nq5y	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Post FB Marketplace listing for Aug 1 oyster class ($79, 6 seats, Englewood)	\N	0	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-06 00:00:00	\N	{"Needs Review",Urgent}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1592atlbyzhvq4z06a	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	c000000000000000000000000019fc5301d15s54sfvdvb5qfwq1q	cmrxkneb300009nph1q2bem5q	Followup with Freddie Lee Cookies Dispensary 719694938	\N	0	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14nxxoew800titr9g0	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	American West Realty & Management — Lead	\N	0	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d109e27pr0wnifu4gi9	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Resolve 6 Critical findings from Phase 10 validation report (11_reviews/validation_report.md)	\N	0	URGENT	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d105i0dujbm3jsgszky	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10cetwe7ya74z8jz17	cmrxkneb300009nph1q2bem5q	K&D Group — James Consolo	\N	0	HIGH	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10kj6d2swi9bs2wcq8	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10d0q0oricqd9ooinb	cmrxkneb300009nph1q2bem5q	Sudler Property Management — 875 North Michigan	\N	0	HIGH	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-31 00:00:00	\N	{Cogent,MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15mrxrfpgpyd417v47	c000000000000000000000000019fc5301d1541ek24xvly4pxv5z	c000000000000000000000000019fc5301d15f3wv5eexd2dlyonj	cmrxshared0000vegahq01	Austin Kolson — State Farm	\N	0	HIGH	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-07 00:00:00	\N	{"Needs Review",Referral}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15gmd8iv93ykgh38sx	c000000000000000000000000019fc5301d15f9yyjspjtdc60che	c000000000000000000000000019fc5301d154w33q41jfozzmylj	cmrxkneb300009nph1q2bem5q	Follow up on Dutchie API access and DPOS review for MDUware integration	\N	0	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-07 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fmr1ql7vkhzekhfgq	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0fjwr7yzvbusps4zfz	cmrxknebk00019nph5p98uh1z	[FM] Migrate existing customers to Shopify store	\N	0	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fecupesyf2mpfcyk0	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Cross-post class to primary FB groups (Mycological Society, Denver Urban Gardens, Colorado Permaculture)	\N	1	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-12 00:00:00	\N	{Human-Required,Urgent}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10r849up0cjnfaqyij	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	Hartford payment	\N	0	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13kuoz1l70bxgqz6et	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Wisper Internet — Lead	\N	0	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d111lt6uk8gw51tg3mp	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	C Spire — Lead	\N	0	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d115mxw80jzd6jynogx	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Ignite Broadband — Lead	\N	0	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-24 00:00:00	\N	{MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14l2uqmi73zat5jiej	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Apartment Management Consultants (AMC) — Lead	\N	1	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0finoe1lmj9n563au6	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	cmrxknebq00029nphxgtlo2sc	[VEL] Engage Colorado counsel to review governance legal-structure research (VEL-RES-GOV-001 v0.3)	\N	1	URGENT	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10bfoavuuyajj94236	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Resolve 12 High findings from Phase 10 validation report	\N	1	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10mhy2lotwkiw4y0w6	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10cetwe7ya74z8jz17	cmrxkneb300009nph1q2bem5q	Bushburg Properties — Priscilla Rukaj	\N	1	HIGH	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1090zqm8bz1rro6r0u	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10d0q0oricqd9ooinb	cmrxkneb300009nph1q2bem5q	Residences at 900 — Brooke Breese / Frank Bramson	\N	1	MEDIUM	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-03 00:00:00	\N	{Cogent,MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15gr8sg7pun1xiyvx5	c000000000000000000000000019fc5301d1541ek24xvly4pxv5z	c000000000000000000000000019fc5301d15f3wv5eexd2dlyonj	cmrxshared0000vegahq01	Ryan Keeley — UniTel Insurance	\N	1	HIGH	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-07 00:00:00	\N	{"Needs Review",Referral}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fvtj1q67xue0a2z7o	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	go through DID Report	\N	1	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10ms8ojtnpx7bp5kdq	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	Comcast ATL payment	\N	1	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fic9xaxtx38jovjvl	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Cross-post class to secondary FB groups (Homesteading, Gardening, Mushroom Growing, Mycology)	\N	2	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-14 00:00:00	\N	{Human-Required}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13jtg5pzg2eli616sh	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Rise Internet (Rise Broadband) — Lead	\N	1	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11x68lqygux2huuvz8	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Metronet — Lead	\N	1	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11i4fx9uhorm7pvcu1	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Swiftcurrent Connect — Lead	\N	1	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-24 00:00:00	\N	{MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14laowxw47wr9exr2f	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Boulder Property Management — Lead	\N	2	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f30f91sngqzmtwb6x	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Order online supplies for oyster class (filters, coir, gypsum, bags, gloves) — ~$54	\N	4	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-10 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fjx5nubqgyiuuqcu9	c000000000000000000000000019fc5301d0fqmpdv8fdp4w8btlx	c000000000000000000000000019fc5301d0f05au0eqq3fk1a307	cmrxshared0000vegahq01	Conduct recurring system review: assess whether current setup is optimal, identify inefficiencies, and evaluate new technologies that could improve efficiency and effectiveness. Summarize recommendations and next steps.	\N	1	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-25 00:00:00	\N	{Human-Required}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10swkvy5y89p8ktrth	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	cmrxknebq00029nphxgtlo2sc	[VEL] Engage tax counsel for Foundation private-inurement analysis, FMV methodology, and related-party transaction framework review	\N	2	URGENT	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10clmsjiijl1497ocl	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Draft Colorado state addenda (VEL-ADD-CO) for each functional area - inquiry, screening, preparation, administration, integration, quality, workforce, facility, technology, growth	\N	2	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10rln9z4v5n68maq00	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10cetwe7ya74z8jz17	cmrxkneb300009nph1q2bem5q	Pacific Elm Properties — Tim / Peridot	\N	2	HIGH	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d102ggvh2jtum3tvnxy	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10d0q0oricqd9ooinb	cmrxkneb300009nph1q2bem5q	Draper and Kramer — 132 East Delaware	\N	2	MEDIUM	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-03 00:00:00	\N	{Cogent,MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d106l8axboelixsvtdj	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	Comcast NAPA payment	\N	2	URGENT	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-03 00:00:00	\N	{Urgent,[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fo68ewzy0ososjech	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Cross-post class to local groups (Englewood Community, Denver Makers/DIY, Colorado Self-Reliance)	\N	3	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-15 00:00:00	\N	{Human-Required}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d139k2hyuidkwnycsrv	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Vexus Fiber — Lead	\N	2	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11mzxz6y3js6in81d5	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Glo Fiber — Lead	\N	2	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d115p4554zzs0r5mbop	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Choptank Fiber — Lead	\N	2	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-24 00:00:00	\N	{MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14bgv512i8dage8ufa	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Celtic Property Management — Lead	\N	3	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1043hjzpq3jvnfdb8w	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	cmrxknebq00029nphxgtlo2sc	[VEL] Engage clinical governance lead to review Care Model Manual (VEL-MAN-CAR v0.2) - scope-of-practice, screening, medical/clinical review process, hard gate	\N	3	URGENT	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10sw3ayqplphbz1won	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Draft 7 inter-entity agreements: Shared Services, Real Estate Lease, IP License, Research Collaboration, Scholarship/Grant, Data Sharing/BAA, Clinical Services	\N	3	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10h5od4hxn19emi9e3	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10d0q0oricqd9ooinb	cmrxkneb300009nph1q2bem5q	RXR Realty — Adam Greene	\N	3	MEDIUM	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-31 00:00:00	\N	{Cogent,MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fo4zqg8gx68o20o7a	c000000000000000000000000019fc5301d0fqmpdv8fdp4w8btlx	c000000000000000000000000019fc5301d0f05au0eqq3fk1a307	cmrxshared0000vegahq01	Define workflow for Anra Foundation (intake, eligibility, approval, and funding process) in a donor-friendly way	\N	2	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10ejcudg15yqf5f0ls	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	Cogent Payment	\N	3	MEDIUM	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13znluewt3qeftmcv6	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Shentel — Lead	\N	3	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11f7esf35mef0anrnt	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	ALLO Communications — Lead	\N	3	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11yt12fp4g3bjapr8i	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Hardy Telecommunications — Lead	\N	3	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-24 00:00:00	\N	{MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14mb4tiv0jfg9r78c0	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Citiside Property Management — Lead	\N	4	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d109iwvrhy2fbnbzf3z	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Finalize technology vendor evaluation - EHR, CRM, LMS, scheduling, inventory per VEL-MAN-TEC build-vs-buy analysis	\N	4	MEDIUM	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d105li79e8469u3ynow	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10d0q0oricqd9ooinb	cmrxkneb300009nph1q2bem5q	InterVest / Rose Associates — Christopher Giovanis / Amy Rose	\N	4	MEDIUM	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-03 00:00:00	\N	{Cogent,MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fimdfhebgsf8y9fga	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	PCI Security compliance questionaire	\N	2	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f3fy02c9e85w2mvot	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Buy local supplies: 8x Sterilite 27qt tubs (Walmart) + verm (Lowe's) + alcohol + spray bottles	\N	5	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-13 00:00:00	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d107rt4ffytvue2vrbx	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	Thomas Howard Atty	\N	4	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d137tm8u4hkzq82ynvl	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Ziply Fiber — Lead	\N	4	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11fvnssv5n4q7qtz6j	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Empire Access — Lead	\N	4	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1190k5o4ybaxguhfhr	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Maryland Broadband Cooperative — Lead	\N	4	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-24 00:00:00	\N	{MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15yejkpu57ifi174sf	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Colorado Realty & Property Management — Lead	\N	5	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10f82ize8xvqmm1otl	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	cmrxknebq00029nphxgtlo2sc	[VEL] Engage insurance broker to design D&O, professional liability, cyber, and entity-separation coverage for three-entity structure	\N	5	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10kzghtqcm1tz7g6st	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10s3x9yi94nrfufvzh	cmrxkneb300009nph1q2bem5q	Transwestern Atlanta — Georgia-Pacific Center	\N	0	MEDIUM	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fcpwtm4ftbi03835v	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Pick up rye grain at Curve Feed (6750 W Mississippi Ave, Lakewood) — 50lb bag $22	\N	6	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-14 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f3kqtpcv3l98l0tz7	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Call Adriana Crawford-David, community Manager The Rocca	\N	3	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d109qein2gqorov6vfj	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	Socketlabs payment	\N	5	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d116mnxmzrlg5q09aav	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Great Plains Communications — Lead	\N	5	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13uzbax7bv0mz081no	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Ritter Communications — Lead	\N	5	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1106cs3i0xu468bxz9	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Washington Electric Cooperative — Lead	\N	5	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-24 00:00:00	\N	{MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15vfilbivdfqq0gdji	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Elite Property Management — Lead	\N	6	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d101ijwvv4cvjqhpj0x	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0f1ioirf5q05bi00af	cmrxknebq00029nphxgtlo2sc	[VEL] Confirm Foundation board independence - recruit independent directors, establish disinterested approval process	\N	6	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10n1vszrl7qxcw9m3b	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Begin facility design and DORA/DNM healing center license application process	\N	6	MEDIUM	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10bw6wq8kpo4ckakfz	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10s3x9yi94nrfufvzh	cmrxkneb300009nph1q2bem5q	BLDG Management — 100 Wall Street	\N	1	MEDIUM	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fmjz780kgv1yyp259	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Drill 6+2 monotubs (6 holes each, 2" hole saw) + take fresh photos	\N	7	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-18 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fsxjo4asdgdkx64nl	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	get tplink APs out of warehouse	\N	4	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10516pdvy4wrgf08v7	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	Digital Ocean payment	\N	6	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13llj21nroqunhhami	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Nex-Tech — Lead	\N	6	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11y9tu25drnm10r8mm	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Lumos (Lumos Fiber) — Lead	\N	6	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11mrxhy0uhea0l9ro5	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Visionary Broadband — Lead	\N	6	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-24 00:00:00	\N	{MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d150sk9q0cflsuwt1hv	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Evernest (Atlanta) — Lead	\N	7	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10d1f7505ozpa1pygd	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Recruit and onboard founding facilitator team - verify NMF/NMCF licensure per VEL-SOP-HR-002	\N	7	MEDIUM	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d107pob306d4wx41axc	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10s3x9yi94nrfufvzh	cmrxkneb300009nph1q2bem5q	Public Square Nassim LLC — 200 Public Square	\N	2	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fbs20dnlz1ebur0p9	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 If class isn't full: re-post in primary FB groups ('Still X seats left for Aug 1')	\N	8	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-20 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f849tcwcauz3fvxtj	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	put wakefield user/pass into controller - get PPSK/DHCP working	\N	5	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{Human-Required}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10ov81m3j055k26crc	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	Coresite payment	\N	7	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-03 00:00:00	\N	{Urgent,[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13bgunjd1c8h5w8hvu	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	West Carolina (WCTEL/WCFiber) — Lead	\N	7	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d112c5y3ka4v6dg4kjn	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	3 Rivers Communications — Lead	\N	7	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d111e2ep23t1hp1g1ih	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	NH Broadband — Lead	\N	7	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-24 00:00:00	\N	{MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15p8treqh2q9neul5n	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Four Star Realty — Lead	\N	8	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10phg5e6yzdpvbbv4p	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Run cross-document consistency review after Colorado addenda are drafted	\N	8	MEDIUM	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11q50o1l0xui1iznrm	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10s3x9yi94nrfufvzh	cmrxkneb300009nph1q2bem5q	Unknown owner — 1301 East 9th Street	\N	3	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f21b0ln5od2x7w4up	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 INOCULATE GRAIN BAGS (6+2 spare) with oyster LC — 7-day colonization starts now	\N	9	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-22 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f1f7k0ms1nhuc9v65	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	update MDUS Invoice template	\N	6	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13lj8nwdogl6lvcw3d	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Point Broadband — Lead	\N	8	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d110ppafdvdrnuz661p	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Greenlight Networks — Lead	\N	8	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11a0c8cilwj95hkz3g	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	All and Beyond Wireless — Lead	\N	8	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d156nnss8xavw79bxkx	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	get MULTIfamily Property Management — Lead	\N	9	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d109awtt4tesvetez7l	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	ToDoIst Payment	\N	8	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10rupiiiq0zv7r2iyr	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Draft VEL-MAN-OPS Operations Manual (Level 2) to consolidate Phase 5 operational policies	\N	9	MEDIUM	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11c12iw3ot1uf9i79z	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10s3x9yi94nrfufvzh	cmrxkneb300009nph1q2bem5q	Unknown owner — 1100 Superior Avenue East	\N	4	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d104m4qgh7hpwixg5zl	c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	c000000000000000000000000019fc5301d10wxyh49i4vxivjpe6	cmrxshared0000vegahq01	medspa beta feedback from 2–3 friendly prospects before pricing	\N	0	URGENT	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{[BIZ]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f6thmopy9s9cm7w2p	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Confirm final attendee count + message all students with class details	\N	10	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-23 00:00:00	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fwfpvxydlz5nc9fk4	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	need signagepro360 logo	\N	7	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13qp3fzeken7pewnji	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Triangle Communications — Lead	\N	9	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11lgolx1f5n8aprw17	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	GeoLinks — Lead	\N	9	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15286a0067pzu8394q	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Grace Property Management — Lead	\N	10	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10o6u21p2mi8fc07sh	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Complete Phase 6 Quality and Safety Manual (VEL-MAN-QMS) - risk register, incident taxonomy, emergency response framework	\N	10	MEDIUM	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10ois6me3zwejamnum	c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	c000000000000000000000000019fc5301d109f5q1k951zr78zj3	cmrxshared0000vegahq01	Interstate TRS - billing	\N	9	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-28 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11ohsil3u3e0ijc44x	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10s3x9yi94nrfufvzh	cmrxkneb300009nph1q2bem5q	Asher Luzzatto / First of Denver Plaza — 621 & 633 17th Street	\N	5	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0frqmbtczasgo2xf6a	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Mix CVG substrate to field capacity + bag into 6 individual portions	\N	11	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-26 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fyt86avy9ssvf34bd	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Need finished case study for linkedin/facebook	\N	8	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13mm50eo9v8y1aso1v	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Northern Telephone Cooperative — Lead	\N	10	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11xq4iooec1z3rkgqz	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Etheric Networks — Lead	\N	10	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1534ud3jocwui3fq6a	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Livingintown Realty Group — Lead	\N	11	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d107zo9vazf4uyjiigz	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fnygaj6to2lzj1l7b	cmrxknebq00029nphxgtlo2sc	[VEL] Create participant-facing plain-language materials - rights summary, consent forms, journey overview, complaint process	\N	11	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11jr8wa8p177ph7s5h	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10s3x9yi94nrfufvzh	cmrxkneb300009nph1q2bem5q	Unknown developer — 208 South LaSalle Street	\N	6	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f9aej5qpufvzcxt1h	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Print 6 care guides + set up 6 student stations	\N	12	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-27 00:00:00	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13qjt5p3so47p5neq9	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	SRT Communications — Lead	\N	11	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11mml2lvh3ljje2t0w	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Aerwave — Lead	\N	11	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15ljekrz6khur3kvzv	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Mission Rock Residential — Lead	\N	12	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0foa1o752mz2juaylf	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Day before class: break up grain bags, wipe surfaces, final setup check	\N	13	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-28 00:00:00	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fjo97e9vz6towhl4b	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Peer with he.net?	\N	9	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{Human-Required,[MDU]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13el0itgh1lfol9br6	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Volcano Communications Group — Lead	\N	12	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11so33gayshc8rlo3c	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	DojoNetworks — Lead	\N	12	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11buejlmpmqt17vz47	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Hello Management — Lead	\N	9	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15prul1wxfafvz8cf3	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Nxt Property Management — Lead	\N	13	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fak2ygefyk9n8xp73	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 CLASS DAY: Oyster Mushroom Growing Class — 10:00 AM at 360 Inverness	\N	14	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-08-29 00:00:00	\N	{Human-Required}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d131aebfnuf80yq1az1	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Panhandle Telephone Cooperative — Lead	\N	13	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11029byegsquxn8pmy	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	GiGstreem — Lead	\N	13	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15tdeh2pnmvz25gwcl	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Pioneer Property Management — Lead	\N	14	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f0crcm505ruu1v18w	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Follow up with all students: 'How's your tub looking?' (3-day check-in)	\N	15	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-09-01 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13to0zm6px3lozcimm	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Sail Internet — Lead	\N	14	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d113rpjadhtc1ldmedo	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Cloud5 Communications — Lead	\N	14	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d153ewekbo47pd6i9w4	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	PMI Georgia — Lead	\N	15	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fbslaz10rxpk6dwuc	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Follow up with all students: 'Any pins yet?' (10-day check-in)	\N	16	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-09-08 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13q6tbh3st5au6v4j5	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Starry Internet (Verizon) — Lead	\N	15	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11sw3l7juqdfusvdaj	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Elauwit — Lead	\N	15	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15sbdt7kvjbbzndr9p	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	RangeWater Real Estate — Lead	\N	16	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fmg44n70vx8utoow5	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	🍄 Ask students for Marketplace reviews + offer refill kits ($25) + decide on next class date	\N	17	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-09-13 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d134yq1ks19nc8bb6v5	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Spot On Networks — Lead	\N	16	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11akexm5m0v2aro6dt	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Internet Subway — Lead	\N	16	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d151s0jln5tcb03sx6y	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Wasatch Property Management — Lead	\N	17	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13upcpmt4pek3954us	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Pavlov Media — Lead	\N	17	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d110ts5v00wgjdy55x7	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Blueport — Lead	\N	17	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d15qxbfxhtigprl7fts	c000000000000000000000000019fc5301d14arn36zzjg30vw69z	c000000000000000000000000019fc5301d14vb3fo2bkokfkro2t	cmrxkneb300009nph1q2bem5q	Wolfnest Property Management — Lead	\N	18	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13bql5l0b0kwxf7q1s	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Nomadix — Lead	\N	18	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11lxiayg369xuj5x9b	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	FirstDigital — Lead	\N	18	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d119nqoh507hgu8zlf9	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Bergan & Company — Lead	\N	10	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f9svd7c7isf47d529	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	LinkedIn Analytics Review	\N	10	MEDIUM	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-07-22 00:00:00	\N	{Human-Required,MDU,Urgent,marketing}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d137hqkls16ccugbxbk	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	SmartRent (Community WiFi) — Lead	\N	19	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1124ucgahlc1d98fzm	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	All Serve Communications — Lead	\N	19	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d116042mja9rxpvnf03	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	The Sherman Agency — Lead	\N	11	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fck0u4kb4ds9ziwo0	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Review Vega's LinkedIn articles	\N	11	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13ridfdmqt5pew0f9e	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	RealPage (WhiteSky WiFi) — Lead	\N	20	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11830yl2xrxqj2msiw	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	anywAIR — Lead	\N	20	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0foko9yjm24yvxu5ec	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	NAPA payment	\N	12	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d137yzu5jf4s3dpa69t	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Smartaira — Lead	\N	21	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1189fck1dm6av78j35	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	EPB (Chattanooga) — Lead	\N	21	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13gfunm551xma89efu	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Wanaport — Lead	\N	22	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11q6vhc736k34ey0u5	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Chattanooga EPB — Lead	\N	22	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11dxa37c2tz6zv6h2h	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Grand Peaks Properties — Lead	\N	12	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d130m2rsl4zp0vb5709	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	WireStar Networks — Lead	\N	23	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11a6bzdzc6d9btj4lt	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	LUS Fiber (Lafayette LA) — Lead	\N	23	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fn053cst8qtol0m5c	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Follow up with Authorize.Net on eCheck/ACH limit review	\N	13	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-05 00:00:00	\N	{Urgent}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13gtryt663r108c3ca	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Ubiquity Smart Buildings — Lead	\N	24	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11fk5umziamb2qlmhb	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Click! Network (Tacoma WA) — Lead	\N	24	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13zral8zlu7rj331zz	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	WhiteSpace — Lead	\N	25	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11h7sm1yzb1uzlyjua	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Cedar Falls Utilities — Lead	\N	25	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0f7ex74zyy6blrvx0n	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fcc4vzxcu71jqg1qj	cmrxkneb300009nph1q2bem5q	Review and follow up on Steve Chatman bandwidth quotes	\N	15	LOW	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-08-07 00:00:00	\N	{}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13ys8byr74we0bmyo7	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Utopia Fiber (UTOPIA) — Lead	\N	26	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d113tzi2n3bdb1damp1	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Co-Mo Connect — Lead	\N	26	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13zedwz45ix9sp0ej6	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	NextLight (Longmont CO) — Lead	\N	27	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11uu0effy9ymxlcjg8	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Callabyte Technology — Lead	\N	27	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13elkibth1luujdq00	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	SandyNet — Lead	\N	28	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11q8xuiovry6rbsyu6	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	GoSEMO Fiber — Lead	\N	28	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13d03m7mjjm87xxbia	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Reedsburg Utility Commission — Lead	\N	29	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11yrrkbb290mvh9hek	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bolt Fiber (NE Oklahoma Electric Co-op) — Lead	\N	29	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1144o2yjc3vn64z44r	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Tarantino Properties — Lead	\N	13	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13endbcxwu86vhp5p3	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	United Fiber (United Electric Co-op) — Lead	\N	30	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11gdjal8k0lnf9b8ub	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Ciello (San Luis Valley) — Lead	\N	30	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13z1w112qgtouog188	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Ouachita Electric ARIS — Lead	\N	31	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11ojhjw0lz2ke225q2	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Elevate (Delta-Montrose EA) — Lead	\N	31	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11ec4lf7konbrcosqy	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Perennial Properties — Lead	\N	14	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13a7n9li2alzb514om	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	South Central Connect — Lead	\N	32	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d116pqxmestqsl023f9	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Firefly Fiber Broadband — Lead	\N	32	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13f45tmfy0ez2cmif3	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	NEXT (N. Arkansas Electric Co-op) — Lead	\N	33	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11iiuni8lp1bped8wp	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	BARC Connects — Lead	\N	33	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11shrl4nwmufntrs44	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	FPA Multifamily — Lead	\N	15	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13h15xv1o7ioxx97wk	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	SECOM (Southeast Colorado Power) — Lead	\N	34	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11qoo12oby9wpn81xw	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Blue Ridge Mountain EMC — Lead	\N	34	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1171jhzbj45z8nophc	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	TCS Management (GA) — Lead	\N	16	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13x7o7h5v2fk0fnvc5	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Red Bolt Broadband — Lead	\N	35	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11kk80uoyvstes85mm	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Freedom Fiber (Tombigbee EC) — Lead	\N	35	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14p1a6c03gok2zxl0u	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	North Alabama Electric Co-op — Lead	\N	36	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11rmpu0a8r5r76b2rg	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Carolina Connect (Mid-Carolina EC) — Lead	\N	36	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d146a606hplw6mzfrwh	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Trailwave (Habersham EMC) — Lead	\N	37	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d115ts7hctjp7cay3pt	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bluewave Communications (Lumbee River EMC) — Lead	\N	37	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d142e8p1sl326csgptk	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	SVEConnect (Sequachee Valley EC) — Lead	\N	38	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11ybd7rjbqmk2da2xl	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Holston Connect — Lead	\N	38	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11kbmju2dmyo7fj5jp	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Revolution Rental Management — Lead	\N	17	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12oaukyzx0j0mtc54a	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	MPU Connect — Lead	\N	39	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14pa9ska1b5p43jeph	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	PES Energize — Lead	\N	39	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12zs54772rwp5ekbex	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	BrightRidge Broadband — Lead	\N	40	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14czg8lwmeh97406j1	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Tullahoma Utilities Board (LightTUBe) — Lead	\N	40	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12u71w2mxsmtcqnqyq	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Clarksville CDE Lightband — Lead	\N	41	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d140ml5ovv2glnonfkc	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Sylacauga Utilities — Lead	\N	41	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11hdj6a046k1uv89oq	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	The Springs Team — Lead	\N	18	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-15 00:00:00	\N	{MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12fp35hpol2x4uql8g	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Erwin Utilities — Lead	\N	42	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14tg8wy1q0e5pya4k2	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Scottsboro EPB — Lead	\N	42	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12dmmvn7h5d48wte7m	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bristol TN Essential Services — Lead	\N	43	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d141yshlx241ej6chrm	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Paragould Light Water & Cable — Lead	\N	43	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12a8740sjup7e9cqjx	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Jackson Energy Authority — Lead	\N	44	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14t91vpm2guj7b7ki3	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Ponca City Technology Services — Lead	\N	44	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12kvzi5yren6jg62ih	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Fibrant (Salisbury NC) — Lead	\N	45	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d140aod472m3tvssec6	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Tuttle Fiber — Lead	\N	45	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12bg4tiw3c36ljfmtu	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Greenlight (Wilson NC) — Lead	\N	46	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14e5owcnnef3n346ev	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	RS Fiber Cooperative — Lead	\N	46	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12coualbatnuqaoz81	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Altitude Community Broadband — Lead	\N	47	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14uah1en8xpzrqegp7	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Swiftel Communications — Lead	\N	47	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12511b3rt36hkssfxi	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Conway Corporation — Lead	\N	48	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d142u1wqhvmcunvplw5	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	XStream Internet (Mille Lacs Energy) — Lead	\N	48	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12saaf96me8dagosnw	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	GEUS (Greenville TX) — Lead	\N	49	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14354stk3z14exlgxv	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	True North (Arrowhead EC) — Lead	\N	49	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12pzvgdgchf8qj2bwl	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bandera Fiber — Lead	\N	50	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14klqnsykj2p297lay	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Plumas-Sierra Telecommunications — Lead	\N	50	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1279e08mz17bsixvmr	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Guadalupe Valley Electric Co-op — Lead	\N	51	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d147f79jhorib97eooa	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Truckee Donner PUD — Lead	\N	51	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12bu23w28cka9770cw	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Grayson Collin Communications — Lead	\N	52	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14rrcfaitp4x5e70cf	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Surf Internet — Lead	\N	52	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12wpfcpwg4ji9onjna	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	MB Link (Merkel TX) — Lead	\N	53	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d145dq107b4eng1vje3	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Omni Fiber — Lead	\N	53	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12t53t1i26c2i9jkla	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	DiamondNet (Miami OK) — Lead	\N	54	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14dzaeni7aw3tx71d1	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Ripple Fiber — Lead	\N	54	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12ertstetcg4neg640	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Lake Region Technology & Communications — Lead	\N	55	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14vi03ewzpfnagjith	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Smithville — Lead	\N	55	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d125zyscwd0miotg6wd	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	MVLink (Maquoketa Valley Electric) — Lead	\N	56	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14hiulgg2qd5et86en	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	ZochNet — Lead	\N	56	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d129p4pz8i0t0oi10cv	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	HomeWorks Connect (Michigan) — Lead	\N	57	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14xjo76h7ectgo3vt3	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	unWired Broadband — Lead	\N	57	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d129gv85cl2153o190a	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Midwest Energy & Communications — Lead	\N	58	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14098xugif9wmu0lzl	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	RV Fiber — Lead	\N	58	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d126ro7cfrswxh3mb6u	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Consolidated Cooperative (OH) — Lead	\N	59	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1410qdvqrccgx8nli5	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Vero Broadband — Lead	\N	59	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d127eb6qfzcx2fr7opx	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Connect Anza — Lead	\N	60	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14tfgmzthzvv64yiz9	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	United Communications — Lead	\N	60	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12a6lg1r7ims0sh24i	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Loma Linda Connected Community — Lead	\N	61	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14nohcru84fbuh16so	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Schurz Broadband Group — Lead	\N	61	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12d3lgpq5okb5bvxer	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	City of Shafter Fiber — Lead	\N	62	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14gushsh873rr3sqbr	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Sonic.net — Lead	\N	62	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12cc8b1sde6l610oj2	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	BalsamWest FiberNET — Lead	\N	63	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14m87sp8p6bvbjledy	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	WideOpenWest (WOW!) — Lead	\N	63	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1276nr4sf3h7ho0khp	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bluebird Network (formerly Bluebird Fiber) — Lead	\N	64	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14drbhimchsl9c7a7g	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Segra — Lead	\N	64	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12ujs4lb2uwj3f5hy7	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Kansas Fiber Network — Lead	\N	65	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d146qej4zubv5amy6sl	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	TDS Telecom — Lead	\N	65	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d124rxcje2z19kxtxd0	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	GoNetspeed — Lead	\N	66	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14bzyhs13tvhuhb5k3	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	NOVOS FiBER — Lead	\N	66	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d123xqgbmcueth3p8iz	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Brightspeed — Lead	\N	67	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14te7nrtvwq6eadwqy	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	RiverStreet Networks — Lead	\N	67	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12jslr4lqcfy2e3alf	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Blue Stream Fiber — Lead	\N	68	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14gajfzwyp4cfw7om4	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Paul Bunyan Communications — Lead	\N	68	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d128unbseilmzb30z39	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bluepeak — Lead	\N	69	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14919dybk7pkiuav9p	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	RS Fiber — Lead	\N	69	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d122yy7wh40d4tcwkfz	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	IQ Fiber — Lead	\N	70	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1407vapiuvt5hotx8t	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Sho-Me Power — Lead	\N	70	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12c0bwckhhubf4a4cf	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Archtop Fiber — Lead	\N	71	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d146bwl7spwpz6343b5	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	NextLight — Lead	\N	71	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d120xkkzzuo45be79l7	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	GigabitNow — Lead	\N	72	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14bvnmkmagb9rgb9sy	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	RUC LightSpeed — Lead	\N	72	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12hlbh66mp96lu12jl	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	AccessParks — Lead	\N	73	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14md7v4x08ix1uw76w	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Spencer Municipal Utilities — Lead	\N	73	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12j5ipz3w53klb0yoh	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Elauwit Connection — Lead	\N	74	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14ocdgf6qrd04dgg7g	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Russellville EPB SmartNet — Lead	\N	74	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12lsk7kbcs1x34c2bl	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	DigitalC — Lead	\N	75	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14jehjobb3mcsy55md	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	OptiLink (Dalton) — Lead	\N	75	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12v95k55d8aycnjhgj	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	ImOn Communications — Lead	\N	76	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14fgpym1oq12rrlnry	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Windomnet — Lead	\N	76	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12vjl6eag6nzs66ihv	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Hotwire Communications — Lead	\N	77	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14yqk8nf2fza1xtlc1	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Wyandotte Municipal Services — Lead	\N	77	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d129caze5eewwdjoy6f	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Ezee Fiber — Lead	\N	78	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d140fsa8te8qh8ulbed	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Traverse City Light & Power — Lead	\N	78	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12e6c56vekq0ggnznf	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bluebird Fiber — Lead	\N	79	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14560279dwd2443ojl	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Ting Internet — Lead	\N	79	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12d353dyr372gcvend	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Aureon — Lead	\N	80	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1440j345tynejvui0k	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	NE Spark — Lead	\N	80	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d121vduox6xoei15haq	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	123NET — Lead	\N	81	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1455855gt2rqgiz0k3	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	NT Spark — Lead	\N	81	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12lrnlj4tic8bvtfud	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Astound Broadband — Lead	\N	82	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14by5yt0pe9c7ehswh	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	OEC Fiber — Lead	\N	82	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12ilaj4ieao8wfl2le	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Midco — Lead	\N	83	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14baqmqu2kdslodkh8	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	OEConnect — Lead	\N	83	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12db2kql241rqwvw7d	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	altafiber — Lead	\N	84	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14tyukhj4yl4ggr57l	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	PearlComm Fiber — Lead	\N	84	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d121gtg20s4c1oqn067	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Hawaiian Telcom — Lead	\N	85	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14ofew741gj2iv32gw	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Pemiscot-Dunklin Fiber — Lead	\N	85	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12ofhv7xqeq1rq3nuz	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	GCI Communications — Lead	\N	86	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d148k21tjzzaf2ul1hv	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Petit Jean Fiber — Lead	\N	86	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1273bea8toffcw5903	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Airebeam — Lead	\N	87	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d148dw1aqr95x2ivqso	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	PIEG Connect — Lead	\N	87	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12zb1bvnhwaajbu988	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Lightcurve — Lead	\N	88	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14j5jkhuwhykntafyf	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Rapid Fiber — Lead	\N	88	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12amee8s74lrjf7cqa	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Firefly Broadband — Lead	\N	89	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14s56zerlp1imkqi2u	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	NEXT (North Arkansas EC) — Lead	\N	89	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12tn2q8jhi8llvf87d	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Allband Communications — Lead	\N	90	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14u9nsronxfcb3mnrr	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Southside Electric Cooperative — Lead	\N	90	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12t114yxhp4o73w4em	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	LS Networks — Lead	\N	91	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14wkt8sab3qhga7slc	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	TriCoLink — Lead	\N	91	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d121sohfg0hj3k9rc8h	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	CRMU LocaLink — Lead	\N	92	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14nk635qy63b4ky5by	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	North Alabama Electric Coop — Lead	\N	92	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12wmepva8idoocwng7	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Connect Waverly — Lead	\N	93	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14h1zvdbibrtv4xmz9	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Ouachita Electric (ARIS) — Lead	\N	93	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12arudatezbgzqah1a	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Highland Communication Services — Lead	\N	94	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14p0tqt8gfxuiq41pq	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Southwest Arkansas Telephone — Lead	\N	94	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d120fs297en6k6tns16	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Auburn Essential Services — Lead	\N	95	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14jb8c6agrfnoy2g8c	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	SEMO Electric Cooperative — Lead	\N	95	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12g7eizezel47p9l94	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	LUSFiber — Lead	\N	96	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d142o7ug254ddmmtu15	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Swyft Connect — Lead	\N	96	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1228h46670zjykp6h0	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Concord Light Broadband — Lead	\N	97	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14zwiwrf6bh9hkcnbn	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	TWN Communications — Lead	\N	97	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d126zvn1xlr7dp26a1n	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Ashland Fiber Network — Lead	\N	98	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14k4sunvzwrcxkjnww	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Stimulus Technologies — Lead	\N	98	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12700n5h1u6jkhgeuh	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	KPU Telecommunications — Lead	\N	99	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14vnnbkz79kty0wmgh	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Premier Broadband — Lead	\N	99	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12a37imptpqrcikg27	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Adams Cable Service — Lead	\N	100	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14p31knzoy778y2m64	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	WispWest — Lead	\N	100	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12yt3vfe1hdm32ldzl	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Advanced Telecom — Lead	\N	101	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14yfs792sz84stbek7	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Wise Broadband — Lead	\N	101	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d122zqzaxr7ew8tmcl3	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Alleghenies Broadband — Lead	\N	102	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14b7j7wo57mfiy49vq	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Upward Broadband — Lead	\N	102	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12mkhi4pbfdyc7kkss	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Armstrong Utilities — Lead	\N	103	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14wbxsw9uwcl249vlt	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Touchstone (Hotel Internet Services) — Lead	\N	103	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d125033u7b6movsknxy	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Beaver Valley Cable — Lead	\N	104	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d140tnmtb247bnid1em	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	SmartRent — Lead	\N	104	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12rf32xcxz0m3l4gb8	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	BearCom — Lead	\N	105	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14lu0a8iy77xp9nq7y	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	NEK Broadband — Lead	\N	105	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12ll5y7iy54fzwiog9	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	MHO Networks — Lead	\N	106	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14keq62qo10kwc3480	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Santel Communications — Lead	\N	106	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12uwjq17402coskkaq	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Microcom — Lead	\N	107	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14zc3bbupxx0o3jkim	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	SDN Communications — Lead	\N	107	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12zunusb42lolik0nl	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	CalNET — Lead	\N	108	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14b9hnfg8s88x6o0nv	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	US Internet — Lead	\N	108	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d122bw4zofg0ju44ver	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Beacon Broadband — Lead	\N	109	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14i7fymd9t5ra5j7me	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Oconee EMC — Lead	\N	109	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1281m8i9vyt6qldx5r	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bolt Fiber — Lead	\N	110	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14joe1bpjhwf6m0mpx	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Northern Neck Electric Cooperative — Lead	\N	110	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12mmfljmvwrn12z0wu	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	CVEC Fiber — Lead	\N	111	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14c8sambtl9htf9htz	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Steelville Telephone Exchange — Lead	\N	111	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d129t2o1wvqw7chnn0y	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Cumberland Connect — Lead	\N	112	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14nb8qa4v7bglgq1zh	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	TCW — Lead	\N	112	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1215qhgdfc1en5f9gs	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Coast Connect — Lead	\N	113	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d141q6zxk1sett0s95b	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	VGI Technology — Lead	\N	113	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d120lle6epi5szfz0xi	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	DE Lightspeed — Lead	\N	114	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14ygyplkyvxzf7cwbh	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Open Broadband — Lead	\N	114	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12zi4srbxgwb1oov7o	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	East Mississippi Connect — Lead	\N	115	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14hthdkcv18boz421k	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Summit Broadband — Lead	\N	115	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d125srm0bnoy9cflwtv	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	EcoLink — Lead	\N	116	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14q1wfc070noz7eodz	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Sierra Nevada Communications — Lead	\N	116	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12o19ph7nm057xdwtn	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Flint Energies — Lead	\N	117	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14wbpfhgua8mduisab	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Siskiyou Telephone — Lead	\N	117	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d123rgam5jodky9ke7o	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Forked Deer Connect — Lead	\N	118	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14a63kaw823xxbxug1	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	SkyHi Broadband — Lead	\N	118	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d123iszpb1wf5qojytc	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	GoSEMO — Lead	\N	119	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d14kmkqrep31f2dxyph	c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	c000000000000000000000000019fc5301d1300jpv3ea2jncyk6m	cmrxkneb300009nph1q2bem5q	Smart Fiber Networks — Lead	\N	119	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12082k9aatd0lbmg70	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Irwin EMC — Lead	\N	120	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d129rjora2mgzgv4rqt	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Kenergy — Lead	\N	121	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12j24l5jdzpxya88xu	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Kosciusko Connect — Lead	\N	122	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12yykwbzxee3lbtgh9	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	M Pulse Fiber — Lead	\N	123	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d121gefwpwzbk8syyya	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	MidSouth Fiber — Lead	\N	124	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12tqo00v26kp1gmkdj	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Mitchell EMC — Lead	\N	125	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d128o8qdwomubg2dg8j	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Centranet — Lead	\N	126	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d128sl94v3xjzyvykc0	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Cookson Hills Connect — Lead	\N	127	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12jqntqlzi4tvoqnmn	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Central Florida EC — Lead	\N	128	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d128ry1ool8ulhvdhg3	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Glades Electric Cooperative — Lead	\N	129	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1223do8lkq0i9a6u3z	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Mountain View Electric — Lead	\N	130	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d126hwovmekk8iyccmx	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Cullman Electric Cooperative — Lead	\N	131	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12f6xcjov9aeq7p0od	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Four States Fiber — Lead	\N	132	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12ofrt5h9j1hdveiqw	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Citynet LLC — Lead	\N	133	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12czsc969cqh05q27y	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Boycom Cablevision — Lead	\N	134	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d122925dv36rn50lzcd	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Cherry Capital Connection — Lead	\N	135	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12wpa5f8fqjf17v6qh	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bertram Communications — Lead	\N	136	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12ol63vpg1wosx6tp7	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bug Tussel Wireless — Lead	\N	137	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d12u6c2isfwdq4f8466	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Fybercom — Lead	\N	138	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d132w7jtui2qwmdi9o6	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Aristotle Unified Comms — Lead	\N	139	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13otwu6toozkrn15mt	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Midwest Energy & Comms — Lead	\N	140	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d131ky2mki0nh5l22w3	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	3 Rivers Telephone Cooperative — Lead	\N	141	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13npmbxmdox2xmxzhu	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Adams Telephone Co-Operative — Lead	\N	142	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d135b5qnyzu5d8alir6	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	AcenTek — Lead	\N	143	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13d5o7rk7qlysbql35	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Agri-Valley Communications — Lead	\N	144	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13p3zax7rs2mi4lhho	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Alliance Communications Cooperative — Lead	\N	145	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13qumkk25tf2dxaff1	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Ben Lomand Telephone Cooperative — Lead	\N	146	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13h6j4fgmxja8jnz5i	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bulloch Telephone Cooperative — Lead	\N	147	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13kqyqfv2texd5ner9	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Cimarron Telephone Co. — Lead	\N	148	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d133ih0vdj32rxgmoad	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Brazos Telephone Cooperative — Lead	\N	149	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13zxwye7zb5dbvp7x7	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Emery Telcom — Lead	\N	150	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13gz0g7b12wspv376s	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Delhi Telephone Company — Lead	\N	151	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13kv4dxw56ilpv51kf	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Germantown Telephone Company — Lead	\N	152	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13wwo440x0xvwwhbig	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Arctic Slope Telephone Association — Lead	\N	153	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d138adz65waknb4lk2o	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Bijou Telephone Cooperative — Lead	\N	154	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13udjcag7amfer70zz	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Cloud5 — Lead	\N	155	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d1395syajj1hzu5260s	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Fidium Fiber — Lead	\N	156	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13f5dirh82a6d5npo1	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Kinetic by Windstream — Lead	\N	157	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d137jse8rlu1jtgvhbf	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Groove — Lead	\N	158	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13l0e48ezoqyy94twe	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	LivePort — Lead	\N	159	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d134xzg9tu5qr7ga82d	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	DV Fiber — Lead	\N	160	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13wk3f29hl1zrzn9ig	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	BroadbandBI — Lead	\N	161	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13otyparj5qekwjd28	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Interstate Telecommunications Cooperative — Lead	\N	162	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d137oa56lmr6c3jfc9d	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Arvig — Lead	\N	163	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13dul8t0x0els5em2p	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Anthem Broadband — Lead	\N	164	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13jkuzc317tbqwn2jf	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Cajun Broadband — Lead	\N	165	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13hf8oanq7qcdof5g0	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Freedom WISP — Lead	\N	166	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13ngp8lizc90lr4exc	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Mohave Electric (TWN Fiber) — Lead	\N	167	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13q6mc6ltbw2pqp797	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Central NM Electric Co-op (Wi-Power) — Lead	\N	168	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13jw37abpqtz70s0wx	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	East Central Energy (ECE) — Lead	\N	169	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d132zv588e0kl3koqfh	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	All Points Broadband — Lead	\N	170	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d134z6zh5weq2nkuazt	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Aristotle Unified — Lead	\N	171	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13ni2by4latc9k6c41	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Matanuska Telecom Association — Lead	\N	172	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13f4ogn4h17n674a7g	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	i3 Broadband — Lead	\N	173	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13179wigdl5ml5ic2y	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Intellipop — Lead	\N	174	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13ejhvm1p9tmki1k09	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Eagle Communications — Lead	\N	175	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13g2vdw4sr5sbur6jg	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	GVTC — Lead	\N	176	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d130zb75iqacc96uuo5	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Gateway Fiber — Lead	\N	177	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13cuvnpzeb9df6zbpx	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	IdeaTek — Lead	\N	178	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d135jho695qxt6ew0ui	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	HighSpeedInternet (Sky Fiber) — Lead	\N	179	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13drny5kj8egifllcd	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Internet For Homes — Lead	\N	180	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d13hl2lpyqt2rnbc81h	c000000000000000000000000019fc5301d1157efats39jo7day2	c000000000000000000000000019fc5301d11ouzuapysuct0f0i7	cmrxkneb300009nph1q2bem5q	Diamond State Networks — Lead	\N	181	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10w1uq9x1vvxp2qk0e	c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	c000000000000000000000000019fc5301d10kgfp6wifbd3tblm6	cmrxkneb300009nph1q2bem5q	Centre Square receivership — 1500 Market Street	\N	0	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	\N	2026-07-29 16:13:57.875	{Cogent,MDU,Pipeline-Lead,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10p03zi0diqcq45vel	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fp3lpiexk9b83jhdv	cmrxknebq00029nphxgtlo2sc	Plan scenic back-road route from Colorado to Virginia: US-36 through Kansas, US-50 through Missouri, and US-60 through Kentucky and West Virginia.	\N	0	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d117rwbwjeiy42et1jh	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Mainstream Fiber Networks — Lead	\N	0	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-24 00:00:00	\N	{MDU,Pipeline-Lead,Urgent,pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fi0twxuk0gd2y4u9w	c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	c000000000000000000000000019fc5301d0fhozpi0821efwr4wj	cmrxkneb300009nph1q2bem5q	Executive review of LinkedIn Articles 1-3 (Resident Experience, Vendor Complexity, Business ROI) — approve for publication	\N	0	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	2026-07-17 00:00:00	\N	{MDU,Urgent,linkedin}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11jbro4pa7cgiz1h1h	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	NextLink Internet — Lead	\N	1	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10t8kq5vabunoka5an	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fp3lpiexk9b83jhdv	cmrxknebq00029nphxgtlo2sc	Draft Velanra Healing Center SOPs: build end-to-end internal SOP set covering Admissions/Eligibility, Preparation, Medicine Session Operations, Integration/Follow-up, and Governance (training, privacy, QA, incident review). Include Colorado compliance check notes and flag for legal review before implementation.	\N	1	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d11flqh8bf30pgqtd4i	c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	c000000000000000000000000019fc5301d11jy3gkx4dee9mzaj8	cmrxkneb300009nph1q2bem5q	Conexon Connect — Lead	\N	2	URGENT	cmrxkneza00049nphloi87ri0	cmrxknens00039nph8q7kzo30	2026-07-14 00:00:00	\N	{MDU,Pipeline-Lead,[MDU],pipeline}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d10lipwi9r6u2hvelzo	c000000000000000000000000019fc5301d0f69xln34llbbp2423	c000000000000000000000000019fc5301d0fp3lpiexk9b83jhdv	cmrxknebq00029nphxgtlo2sc	Create and finalize Helix Center pre-screening and intake SOP for psychedelic-assisted therapy. Include purpose, scope/ownership, eligibility/contraindications, checklist workflow (prep, initial contact, consent/disclosures, screening, documentation, compliance checkpoint, decision/outcome, audit trail), and pause-and-escalate criteria. Ensure review by appropriate licensed/legal/compliance stakeholders and alignment with Colorado Natural Medicine program resources.	\N	2	HIGH	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fnz3g4a9v0e5nvvhs	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Provide Flying Mushroom substrate ingredient sourcing — current suppliers and any gaps	\N	9	MEDIUM	\N	cmrxknens00039nph8q7kzo30	\N	\N	{Human-Required,[FM]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0ftmj2xma6kkhsfii4	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Provide Flying Mushroom equipment list — what you have and what you need for production	\N	10	MEDIUM	\N	cmrxknens00039nph8q7kzo30	\N	\N	{Human-Required,[FM]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fcg9hmqbzvw1oas6l	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Take Flying Mushroom product photos — shot list provided below	\N	11	MEDIUM	\N	cmrxknens00039nph8q7kzo30	\N	\N	{Human-Required,[FM]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0flv9aa4dx441ggzdc	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	Provide Flying Mushroom product catalog — list of strains, product types, and quantities for Shopify launch	\N	12	MEDIUM	\N	cmrxknens00039nph8q7kzo30	\N	\N	{Human-Required,[FM]}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
c000000000000000000000000019fc5301d0fdlkhtvm1w3lkq6qm	c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	c000000000000000000000000019fc5301d0f0asg5izycf2e6uw5	cmrxknebk00019nph5p98uh1z	research what costs are and steps setup and implement an etsy shop	\N	13	LOW	cmrxknens00039nph8q7kzo30	cmrxknens00039nph8q7kzo30	\N	\N	{"Needs Review"}	\N	2026-08-03 01:14:59.1	2026-08-03 04:31:44.357
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, "tenantId", name, description, color, icon, "isArchived", "createdById", "createdAt", "updatedAt") FROM stdin;
c000000000000000000000000019fc5301d0e500psqpmmogpuc6k	cmrxshared0000vegahq01	Inbox		#c9a96e	📥	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fqmpdv8fdp4w8btlx	cmrxshared0000vegahq01	New Tasks		#c9a96e	✨	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fgrt2qlme190wwy5z	cmrxkneb300009nph1q2bem5q	[MDU] MDU Solutions		#c9a96e	🏢	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0fgesoemg1x6llfc7h	cmrxknebk00019nph5p98uh1z	[FM] Flying Mushroom		#c9a96e	🍄	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d0f69xln34llbbp2423	cmrxknebq00029nphxgtlo2sc	[VEL] Velanra Healing Center		#c9a96e	🌿	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d109f6mv6erd07i4stw	cmrxshared0000vegahq01	Completed / Activity Log		#c9a96e	📋	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d100jdq0lpdo4cr9a21	cmrxshared0000vegahq01	Business Ideas		#c9a96e	💡	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10obkjt6smotqial2c	cmrxknebq00029nphxgtlo2sc	[ANR] Anra Foundation		#c9a96e	🌟	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10kp51odxb096lgtfq	cmrxknebq00029nphxgtlo2sc	[VLA] Vela Institute		#c9a96e	🔬	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10sei1skdnpo8a79dj	cmrxshared0000vegahq01	[AP] Accounts Payable		#c9a96e	💳	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d10cg17aougccqenfdd	cmrxkneb300009nph1q2bem5q	MDUware Sales		#c9a96e	📊	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d109xp1bdf29lcux0fk	cmrxkneb300009nph1q2bem5q	Cogent MDU Prospects		#c9a96e	🎯	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d119k5eya8hcwd35nka	cmrxkneb300009nph1q2bem5q	ISP Outreach — Active		#c9a96e	📡	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d11xtbhceoq32a3vrio	cmrxkneb300009nph1q2bem5q	ISP Outreach — Follow-Up		#c9a96e	📞	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d1157efats39jo7day2	cmrxkneb300009nph1q2bem5q	ISP Outreach — Backlog A-M		#c9a96e	📑	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d136bvexb8q0vgycy4s	cmrxkneb300009nph1q2bem5q	ISP Outreach — Backlog N-Z		#c9a96e	📑	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d14arn36zzjg30vw69z	cmrxkneb300009nph1q2bem5q	Property Management Outreach		#c9a96e	🏘️	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d15f9yyjspjtdc60che	cmrxkneb300009nph1q2bem5q	SignagePro360 Sales		#c9a96e	📢	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
c000000000000000000000000019fc5301d1541ek24xvly4pxv5z	cmrxshared0000vegahq01	Referral & Partner Outreach		#c9a96e	🤝	f	cmrxknens00039nph8q7kzo30	2026-08-03 01:14:59.1	2026-08-03 01:14:59.1
\.


--
-- Data for Name: quote_line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_line_items (id, "quoteId", description, quantity, "unitPrice", total) FROM stdin;
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotes (id, "dealId", "tenantId", number, status, subtotal, "taxRate", "taxAmount", total, notes, "validUntil", "sentAt", "acceptedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: sequence_enrollment_steps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sequence_enrollment_steps (id, "enrollmentId", "stepId", status, "scheduledFor", "sentAt", "emailMessageId") FROM stdin;
\.


--
-- Data for Name: sequence_enrollments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sequence_enrollments (id, "sequenceId", "contactId", "tenantId", status, "enrolledAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: sequence_steps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sequence_steps (id, "sequenceId", "templateId", "stepNumber", "delayDays", "sendTime", "createdAt") FROM stdin;
\.


--
-- Data for Name: sms_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_messages (id, "tenantId", "contactId", "userId", direction, body, status, "externalId", "fromNumber", "toNumber", "createdAt") FROM stdin;
\.


--
-- Data for Name: subtasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subtasks (id, "taskId", title, "isCompleted", "position", "assignedToId", "dueDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_comments (id, "taskId", "tenantId", "userId", body, "createdAt", "updatedAt") FROM stdin;
cmrxfhvry87ie4s9xwwge1c8cd1uxe88xp8ne55f5y4s	c000000000000000000000000019fc5301d0fsisgj9h9p2uhtrly	cmrxkneb300009nph1q2bem5q	cmrxkneza00049nphloi87ri0	📞 CALL — Tue Aug 4, 2026 (morning)\nLeon called Coby Brown at OzarksGo and left a voicemail.\nOutcome: Voicemail left\nDirection: Outbound\nStatus: Awaiting Response	2026-08-04 15:10:36	2026-08-04 15:10:36
cmrxsbjrbwzdf6lu9mzjgb4r9vbqowm0xrqy3o24se5e	c000000000000000000000000019fc5301d0f0okyi120kzz6r1mq	cmrxkneb300009nph1q2bem5q	cmrxkneza00049nphloi87ri0	✉️ EMAIL — Tue Aug 4, 2026\nLeon sent a follow-up email to Peter, Liliana, and Anuja at U.S. Bank regarding:\n1. Adding CyberSource and Global Payments Company IDs to the MDU Solutions account ending in 5604\n2. A brief vendor letter confirming that a banking issue affected access to funds and payments\n3. Activating MDU Solutions' online banking access\nStatus: Awaiting response from U.S. Bank.	2026-08-04 15:10:36	2026-08-04 15:10:36
cmrxnwu3t0n68d4typ3k1h4pz1nlm1f9tbhifq9at3y5	c000000000000000000000000019fc5301d0fsisgj9h9p2uhtrly	cmrxkneb300009nph1q2bem5q	cmrxkneza00049nphloi87ri0	📞 CALL — Tue Aug 4 (morning): Voicemail left for Coby Brown. Status: Awaiting response. Call recorded in Vega CRM activity history.	2026-08-04 23:15:29	2026-08-04 23:15:29
cmrxn98sybpzspv7ldcwcf9o0d27bmymkyfnbf2xwr76	c000000000000000000000000019fc5301d0f0okyi120kzz6r1mq	cmrxkneb300009nph1q2bem5q	cmrxkneza00049nphloi87ri0	✉️ EMAIL UPDATE — Tue Aug 4:\n• Follow-up email sent to Peter, Liliana, and Anuja re: Company IDs, vendor letter, online banking access.\n• U.S. Bank provided a letter but it does NOT contain the explanation needed for vendors.\n• Bryan does NOT want to request another letter — vendor letter follow-up CLOSED. Do not ask again.\n• Remaining items: (1) confirmation that CyberSource and Global Payments Company IDs were added, (2) activation of online banking access.\n• Status: Awaiting response.	2026-08-04 23:15:29	2026-08-04 23:15:29
cmrxf9fwbgs72trz1aifdgphit2boxo8cndlwq3tq7xc	c000000000000000000000000019fc5301d0fn053cst8qtol0m5c	cmrxkneb300009nph1q2bem5q	cmrxkneza00049nphloi87ri0	📋 UPDATE — Tue Aug 4:\nCase 002499798 (deposit bank-account update):\n• Update received: 'We have updated your bank account information.'\n• NOT confirmed: effective date, whether future settlements go to new U.S. Bank account, whether any pending payout was routed to prior bank, whether a temporary payout hold is still needed.\n\nCase 002499160 (eCheck/ACH processing-limit increase + reduced hold-time request):\n• Remains separate. Additional verification still required.\n\nWednesday priorities: confirm effective date, settlement routing, hold status, and eCheck/ACH limit + hold-time request status.	2026-08-04 23:15:29	2026-08-04 23:15:29
cmrx8bhaaaxd31p5cimlu8ttmq3mfg6rgm2j1rnlc2a0	c000000000000000000000000019fc5301d0foko9yjm24yvxu5ec	cmrxkneb300009nph1q2bem5q	cmrxkneza00049nphloi87ri0	💰 UPDATE — Tue Aug 4:\n• Check received Saturday and deposited. Expected to clear Friday, August 7.\n• Peyton asked to provide ACH fee information so appropriate credit can begin with next invoice.\n• Updated U.S. Bank ACH information provided for future payments.\n• Monitor for clearance and Peyton's response.	2026-08-04 23:15:29	2026-08-04 23:15:29
cmrxre1xoutophtmcoarvlgv65eg5px4smvuhrr4vqwe	78799206-e09a-4541-98c7-7f03f5638460	cmrxkneb300009nph1q2bem5q	cmrxkneza00049nphloi87ri0	📋 UPDATE — Tue Aug 4:\n• Sam Pines sent an additional update.\n• More information expected within the next day or two.\n• Preserve and review the new information, but keep the quote open.\n• Do NOT finalize the spreadsheet until the additional update arrives.\n• Keep Steve's quote SEPARATE from the Cogent MDU project.	2026-08-04 23:15:29	2026-08-04 23:15:29
cmrx473wp69vy1vlvqlphaviki35s80om38xf77n4a40	fc72bf9d-c2b9-4aba-834a-2c3e97e4cabd	cmrxkneb300009nph1q2bem5q	cmrxkneza00049nphloi87ri0	📋 UPDATE — Tue Aug 4: BOP reconciliation in progress. Wednesday priority.	2026-08-04 23:15:29	2026-08-04 23:15:29
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, "tenantId", "companyId", "contactId", title, description, status, priority, "assignedToId", "createdById", "dueDate", "completedAt", "createdAt", "updatedAt") FROM stdin;
cmrxomy1bbe9ekkrd8pzq8632v5xr9tdqmlv4jfb8n5j	cmrxkneb300009nph1q2bem5q	cmrxhpibz0h9eccqpcyt2s2ukb653zqzaie3qdhn5z64	cmrxu8he7lbddkwwlg5h73agsmz30obgy9qc07z428bs	Follow up with Coby Brown at OzarksGo	Leon called Coby Brown at OzarksGo on Tuesday morning (Aug 4, 2026) and left a voicemail. Awaiting response.	IN_PROGRESS	HIGH	cmrxkneza00049nphloi87ri0	cmrxkneza00049nphloi87ri0	2026-08-05 00:00:00	\N	2026-08-04 15:09:14	2026-08-04 15:09:14
cmrxw0q6fo2wjp99o7zdurndgswughdcl317w4nwqtpx	cmrxkneb300009nph1q2bem5q	cmrxig5tj7oixvzrk1kyiukzy9ektal2fzsml0toeciz	cmrxfi5ypnellqtt307ncnlj75x70d1tkqquthjrquyo	Get U.S. Bank online banking operational	Leon sent a follow-up email to Peter, Liliana, and Anuja at U.S. Bank regarding:\n1. Adding CyberSource and Global Payments Company IDs to the MDU Solutions account ending in 5604\n2. A brief vendor letter confirming that a banking issue affected access to funds and payments\n3. Activating MDU Solutions' online banking access\nStatus: Awaiting response from U.S. Bank.	IN_PROGRESS	MEDIUM	cmrxkneza00049nphloi87ri0	cmrxkneza00049nphloi87ri0	2026-07-31 00:00:00	\N	2026-08-04 15:09:14	2026-08-04 15:09:14
\.


--
-- Data for Name: tenant_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenant_settings (id, "tenantId", key, value, "isEncrypted", "updatedAt", "updatedBy") FROM stdin;
cmscrbfq1000198ute9ui6jw7	cmrxkneb300009nph1q2bem5q	google_oauth_redirect_uri	https://earth.servers.onl/api/google/auth?tenant=mdu	f	2026-08-03 04:56:32.857	cmrxknens00039nph8q7kzo30
cmse51c1e000ay1hsats7ghmb	cmrxkneb300009nph1q2bem5q	google_oauth_client_id	1043108780486-nt98avhijed7n63u0vin0h4qeg52tmas.apps.googleusercontent.com	f	2026-08-04 04:08:22.322	cmrxknens00039nph8q7kzo30
cmse51g70000cy1hsfqx3ubdm	cmrxkneb300009nph1q2bem5q	google_oauth_client_secret	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	t	2026-08-04 04:08:27.708	cmrxknens00039nph8q7kzo30
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, slug, description, "isActive", "createdAt", "updatedAt") FROM stdin;
cmrxkneb300009nph1q2bem5q	MDU Solutions	mdu-solutions	Telecom, IPTV, and property technology solutions	t	2026-07-23 13:53:20.943	2026-07-23 13:53:20.943
cmrxknebk00019nph5p98uh1z	Flying Mushroom	flying-mushroom	Colorado gourmet and functional mushroom cultivation	t	2026-07-23 13:53:20.944	2026-07-23 13:53:20.944
cmrxknebq00029nphxgtlo2sc	Velanra	velanra	Wellness ecosystem and retreats	t	2026-07-23 13:53:20.944	2026-07-23 13:53:20.944
cmrxshared0000vegahq01	Vega HQ (Shared)	vega-hq	\N	t	2026-08-03 01:08:38.199	2026-08-03 01:08:38.199
\.


--
-- Data for Name: user_tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_tenants (id, "userId", "tenantId", "createdAt") FROM stdin;
cmscpggxb00017cfgtzdmboyg	cmrxknens00039nph8q7kzo30	cmrxknebk00019nph5p98uh1z	2026-08-03 04:04:28.463
cmscpggxb00027cfgt128yvx8	cmrxknens00039nph8q7kzo30	cmrxkneb300009nph1q2bem5q	2026-08-03 04:04:28.463
cmscpggxb00037cfglljqvgbt	cmrxknens00039nph8q7kzo30	cmrxshared0000vegahq01	2026-08-03 04:04:28.463
cmscpggxb00047cfg2uzocp0h	cmrxknens00039nph8q7kzo30	cmrxknebq00029nphxgtlo2sc	2026-08-03 04:04:28.463
780367a4-4fd2-4831-bca4-3bb13e120c9b	fafc63fb-db10-49d4-b3ba-3f7974e464e1	cmrxkneb300009nph1q2bem5q	2026-08-03 04:27:15.533
08537bac-821f-4cc1-a6d6-e06d787f8812	fafc63fb-db10-49d4-b3ba-3f7974e464e1	cmrxknebk00019nph5p98uh1z	2026-08-03 04:27:15.533
1b14ee6f-e4c2-437c-814b-08e3301f77c3	fafc63fb-db10-49d4-b3ba-3f7974e464e1	cmrxknebq00029nphxgtlo2sc	2026-08-03 04:27:15.533
ece6583f-2624-4f8d-a70e-6c67ef772c36	fafc63fb-db10-49d4-b3ba-3f7974e464e1	cmrxshared0000vegahq01	2026-08-03 04:27:15.533
cmsdmq8bk0007y1hsvv37ki4z	cmrxkneza00049nphloi87ri0	cmrxkneb300009nph1q2bem5q	2026-08-03 19:35:51.2
cmsdmq8bk0008y1hsdht3i77g	cmrxkneza00049nphloi87ri0	cmrxknebk00019nph5p98uh1z	2026-08-03 19:35:51.2
cmse520xb000fy1hskx5x7k5m	cmse520xb000dy1hskdgb8fgr	cmrxknebk00019nph5p98uh1z	2026-08-04 04:08:54.575
cmse520xb000gy1hskv4c9fh7	cmse520xb000dy1hskdgb8fgr	cmrxkneb300009nph1q2bem5q	2026-08-04 04:08:54.575
cmse520xb000hy1hszneo1pwg	cmse520xb000dy1hskdgb8fgr	cmrxshared0000vegahq01	2026-08-04 04:08:54.575
cmse520xb000iy1hswks9600a	cmse520xb000dy1hskdgb8fgr	cmrxknebq00029nphxgtlo2sc	2026-08-04 04:08:54.575
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, "passwordHash", "globalRole", "isActive", "totpSecret", "totpEnabled", "totpBackupCodes", "lastLoginAt", "lastLoginIp", "failedLoginAttempts", "lockedUntil", "createdAt", "updatedAt", "googleAccessToken", "googleEmail", "googleRefreshToken", "googleScope", "googleTokenExpiry") FROM stdin;
cmrxkneza00049nphloi87ri0	leon.zetekoff@mdusolutions.com	Leon Zetekoff	$2a$10$pA5oh03f3EoSPgA1SL80FuNFnrnHrtb9/YZYjfT8XhtlblcGLEk9S	SUPER_ADMIN	t	\N	f	{}	2026-08-03 19:36:09.819	\N	0	\N	2026-07-23 13:53:21.814	2026-08-03 19:36:09.821	\N	\N	\N	\N	\N
cmse520xb000dy1hskdgb8fgr	bryan.paulk@mdusolutions.com	Bryan Paulk	$2a$10$in9yjiPtnm86XUQbeZozLOD17jlpWP5gojpsgjkyTHpJO4ln93Rxq	SUPER_ADMIN	t	\N	f	{}	2026-08-04 04:09:06.971	\N	0	\N	2026-08-04 04:08:54.575	2026-08-04 04:09:06.972	\N	\N	\N	\N	\N
cmrxknfam00099nphr69n8u1j	bob@mdusolutions.com	Bob	$2a$10$/uT8fXmQuq0snZHqEQbEceTkp1gpY.b8hsjDvVdNE55.iYU9zVfQG	USER	t	\N	f	{}	\N	\N	0	\N	2026-07-23 13:53:22.223	2026-08-05 04:38:30.177	\N	\N	\N	\N	\N
fafc63fb-db10-49d4-b3ba-3f7974e464e1	vega.sterling@mdusolutions.com	Vega Sterling	$2b$10$rK48RtzDOm6AzLwZ37tlgu7ruphCG/4A/LEx9MgFnllmtJylPMP1S	SUPER_ADMIN	t	\N	f	{}	2026-08-05 04:54:26.285	\N	0	\N	2026-08-03 04:27:15.533	2026-08-05 04:54:26.285	\N	\N	\N	\N	\N
cmrxknens00039nph8q7kzo30	bryan@paulk.org	Bryan Paulk	$2a$10$/uT8fXmQuq0snZHqEQbEceTkp1gpY.b8hsjDvVdNE55.iYU9zVfQG	SUPER_ADMIN	t	\N	f	{}	2026-08-05 05:44:00.826	\N	0	\N	2026-07-23 13:53:21.4	2026-08-05 05:44:00.827	\N	\N	\N	\N	\N
\.


--
-- Data for Name: workflow_executions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_executions (id, "workflowId", "entityId", "entityType", status, result, error, "executedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflows (id, "tenantId", name, description, "isActive", trigger, "triggerConfig", conditions, actions, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: booking_slots booking_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_slots
    ADD CONSTRAINT booking_slots_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: custom_properties custom_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_properties
    ADD CONSTRAINT custom_properties_pkey PRIMARY KEY (id);


--
-- Name: custom_property_values custom_property_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_property_values
    ADD CONSTRAINT custom_property_values_pkey PRIMARY KEY (id);


--
-- Name: deals deals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_pkey PRIMARY KEY (id);


--
-- Name: email_campaign_recipients email_campaign_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaign_recipients
    ADD CONSTRAINT email_campaign_recipients_pkey PRIMARY KEY (id);


--
-- Name: email_campaigns email_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_pkey PRIMARY KEY (id);


--
-- Name: email_clicks email_clicks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_clicks
    ADD CONSTRAINT email_clicks_pkey PRIMARY KEY (id);


--
-- Name: email_messages email_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT email_messages_pkey PRIMARY KEY (id);


--
-- Name: email_opens email_opens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_opens
    ADD CONSTRAINT email_opens_pkey PRIMARY KEY (id);


--
-- Name: email_sequences email_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sequences
    ADD CONSTRAINT email_sequences_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: lead_form_submissions lead_form_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_form_submissions
    ADD CONSTRAINT lead_form_submissions_pkey PRIMARY KEY (id);


--
-- Name: lead_forms lead_forms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_forms
    ADD CONSTRAINT lead_forms_pkey PRIMARY KEY (id);


--
-- Name: lead_score_rules lead_score_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_score_rules
    ADD CONSTRAINT lead_score_rules_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: pipeline_stages pipeline_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pipeline_stages
    ADD CONSTRAINT pipeline_stages_pkey PRIMARY KEY (id);


--
-- Name: project_columns project_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_columns
    ADD CONSTRAINT project_columns_pkey PRIMARY KEY (id);


--
-- Name: project_tasks project_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: quote_line_items quote_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_line_items
    ADD CONSTRAINT quote_line_items_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: sequence_enrollment_steps sequence_enrollment_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequence_enrollment_steps
    ADD CONSTRAINT sequence_enrollment_steps_pkey PRIMARY KEY (id);


--
-- Name: sequence_enrollments sequence_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequence_enrollments
    ADD CONSTRAINT sequence_enrollments_pkey PRIMARY KEY (id);


--
-- Name: sequence_steps sequence_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequence_steps
    ADD CONSTRAINT sequence_steps_pkey PRIMARY KEY (id);


--
-- Name: sms_messages sms_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_messages
    ADD CONSTRAINT sms_messages_pkey PRIMARY KEY (id);


--
-- Name: subtasks subtasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT subtasks_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_tenants user_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workflow_executions workflow_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: activities_companyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "activities_companyId_idx" ON public.activities USING btree ("companyId");


--
-- Name: activities_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "activities_createdAt_idx" ON public.activities USING btree ("createdAt");


--
-- Name: activities_dealId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "activities_dealId_idx" ON public.activities USING btree ("dealId");


--
-- Name: activities_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "activities_tenantId_idx" ON public.activities USING btree ("tenantId");


--
-- Name: activities_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activities_type_idx ON public.activities USING btree (type);


--
-- Name: activities_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "activities_userId_idx" ON public.activities USING btree ("userId");


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_entity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_entity_idx ON public.audit_logs USING btree (entity);


--
-- Name: audit_logs_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_userId_idx" ON public.audit_logs USING btree ("userId");


--
-- Name: booking_slots_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "booking_slots_tenantId_idx" ON public.booking_slots USING btree ("tenantId");


--
-- Name: booking_slots_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "booking_slots_userId_idx" ON public.booking_slots USING btree ("userId");


--
-- Name: bookings_bookingSlotId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "bookings_bookingSlotId_idx" ON public.bookings USING btree ("bookingSlotId");


--
-- Name: bookings_contactId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "bookings_contactId_idx" ON public.bookings USING btree ("contactId");


--
-- Name: bookings_slotId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "bookings_slotId_idx" ON public.bookings USING btree ("slotId");


--
-- Name: calendar_events_startAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "calendar_events_startAt_idx" ON public.calendar_events USING btree ("startAt");


--
-- Name: calendar_events_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "calendar_events_tenantId_idx" ON public.calendar_events USING btree ("tenantId");


--
-- Name: calendar_events_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "calendar_events_userId_idx" ON public.calendar_events USING btree ("userId");


--
-- Name: companies_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "companies_tenantId_idx" ON public.companies USING btree ("tenantId");


--
-- Name: contacts_companyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "contacts_companyId_idx" ON public.contacts USING btree ("companyId");


--
-- Name: contacts_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "contacts_tenantId_idx" ON public.contacts USING btree ("tenantId");


--
-- Name: custom_properties_entity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX custom_properties_entity_idx ON public.custom_properties USING btree (entity);


--
-- Name: custom_properties_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "custom_properties_tenantId_idx" ON public.custom_properties USING btree ("tenantId");


--
-- Name: custom_property_values_entityId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "custom_property_values_entityId_idx" ON public.custom_property_values USING btree ("entityId");


--
-- Name: custom_property_values_propertyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "custom_property_values_propertyId_idx" ON public.custom_property_values USING btree ("propertyId");


--
-- Name: deals_assignedToId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "deals_assignedToId_idx" ON public.deals USING btree ("assignedToId");


--
-- Name: deals_companyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "deals_companyId_idx" ON public.deals USING btree ("companyId");


--
-- Name: deals_stageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "deals_stageId_idx" ON public.deals USING btree ("stageId");


--
-- Name: deals_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deals_status_idx ON public.deals USING btree (status);


--
-- Name: deals_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "deals_tenantId_idx" ON public.deals USING btree ("tenantId");


--
-- Name: email_campaign_recipients_campaignId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_campaign_recipients_campaignId_idx" ON public.email_campaign_recipients USING btree ("campaignId");


--
-- Name: email_campaigns_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_campaigns_tenantId_idx" ON public.email_campaigns USING btree ("tenantId");


--
-- Name: email_clicks_emailMessageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_clicks_emailMessageId_idx" ON public.email_clicks USING btree ("emailMessageId");


--
-- Name: email_messages_companyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_messages_companyId_idx" ON public.email_messages USING btree ("companyId");


--
-- Name: email_messages_contactId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_messages_contactId_idx" ON public.email_messages USING btree ("contactId");


--
-- Name: email_messages_direction_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_messages_direction_idx ON public.email_messages USING btree (direction);


--
-- Name: email_messages_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_messages_tenantId_idx" ON public.email_messages USING btree ("tenantId");


--
-- Name: email_messages_threadId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_messages_threadId_idx" ON public.email_messages USING btree ("threadId");


--
-- Name: email_messages_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_messages_userId_idx" ON public.email_messages USING btree ("userId");


--
-- Name: email_opens_emailMessageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_opens_emailMessageId_idx" ON public.email_opens USING btree ("emailMessageId");


--
-- Name: email_sequences_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_sequences_tenantId_idx" ON public.email_sequences USING btree ("tenantId");


--
-- Name: email_templates_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "email_templates_tenantId_idx" ON public.email_templates USING btree ("tenantId");


--
-- Name: idx_task_comments_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_comments_task_id ON public.task_comments USING btree ("taskId");


--
-- Name: idx_task_comments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_comments_tenant_id ON public.task_comments USING btree ("tenantId");


--
-- Name: lead_form_submissions_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "lead_form_submissions_createdAt_idx" ON public.lead_form_submissions USING btree ("createdAt");


--
-- Name: lead_form_submissions_formId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "lead_form_submissions_formId_idx" ON public.lead_form_submissions USING btree ("formId");


--
-- Name: lead_forms_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lead_forms_slug_key ON public.lead_forms USING btree (slug);


--
-- Name: lead_forms_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "lead_forms_tenantId_idx" ON public.lead_forms USING btree ("tenantId");


--
-- Name: lead_score_rules_tenantId_event_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "lead_score_rules_tenantId_event_key" ON public.lead_score_rules USING btree ("tenantId", event);


--
-- Name: notifications_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "notifications_createdAt_idx" ON public.notifications USING btree ("createdAt");


--
-- Name: notifications_userId_isRead_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "notifications_userId_isRead_idx" ON public.notifications USING btree ("userId", "isRead");


--
-- Name: pipeline_stages_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "pipeline_stages_tenantId_idx" ON public.pipeline_stages USING btree ("tenantId");


--
-- Name: project_columns_projectId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "project_columns_projectId_idx" ON public.project_columns USING btree ("projectId");


--
-- Name: project_tasks_assignedToId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "project_tasks_assignedToId_idx" ON public.project_tasks USING btree ("assignedToId");


--
-- Name: project_tasks_columnId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "project_tasks_columnId_idx" ON public.project_tasks USING btree ("columnId");


--
-- Name: project_tasks_projectId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "project_tasks_projectId_idx" ON public.project_tasks USING btree ("projectId");


--
-- Name: project_tasks_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "project_tasks_tenantId_idx" ON public.project_tasks USING btree ("tenantId");


--
-- Name: projects_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "projects_tenantId_idx" ON public.projects USING btree ("tenantId");


--
-- Name: quote_line_items_quoteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "quote_line_items_quoteId_idx" ON public.quote_line_items USING btree ("quoteId");


--
-- Name: quotes_dealId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "quotes_dealId_idx" ON public.quotes USING btree ("dealId");


--
-- Name: quotes_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "quotes_tenantId_idx" ON public.quotes USING btree ("tenantId");


--
-- Name: sequence_enrollment_steps_enrollmentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sequence_enrollment_steps_enrollmentId_idx" ON public.sequence_enrollment_steps USING btree ("enrollmentId");


--
-- Name: sequence_enrollment_steps_stepId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sequence_enrollment_steps_stepId_idx" ON public.sequence_enrollment_steps USING btree ("stepId");


--
-- Name: sequence_enrollments_contactId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sequence_enrollments_contactId_idx" ON public.sequence_enrollments USING btree ("contactId");


--
-- Name: sequence_enrollments_sequenceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sequence_enrollments_sequenceId_idx" ON public.sequence_enrollments USING btree ("sequenceId");


--
-- Name: sequence_enrollments_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sequence_enrollments_tenantId_idx" ON public.sequence_enrollments USING btree ("tenantId");


--
-- Name: sequence_steps_sequenceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sequence_steps_sequenceId_idx" ON public.sequence_steps USING btree ("sequenceId");


--
-- Name: sms_messages_contactId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sms_messages_contactId_idx" ON public.sms_messages USING btree ("contactId");


--
-- Name: sms_messages_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sms_messages_createdAt_idx" ON public.sms_messages USING btree ("createdAt");


--
-- Name: sms_messages_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sms_messages_tenantId_idx" ON public.sms_messages USING btree ("tenantId");


--
-- Name: subtasks_taskId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "subtasks_taskId_idx" ON public.subtasks USING btree ("taskId");


--
-- Name: tasks_assignedToId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tasks_assignedToId_idx" ON public.tasks USING btree ("assignedToId");


--
-- Name: tasks_dueDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tasks_dueDate_idx" ON public.tasks USING btree ("dueDate");


--
-- Name: tasks_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_status_idx ON public.tasks USING btree (status);


--
-- Name: tasks_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tasks_tenantId_idx" ON public.tasks USING btree ("tenantId");


--
-- Name: tenant_settings_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tenant_settings_tenantId_idx" ON public.tenant_settings USING btree ("tenantId");


--
-- Name: tenant_settings_tenantId_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "tenant_settings_tenantId_key_key" ON public.tenant_settings USING btree ("tenantId", key);


--
-- Name: tenants_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tenants_slug_key ON public.tenants USING btree (slug);


--
-- Name: user_tenants_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "user_tenants_tenantId_idx" ON public.user_tenants USING btree ("tenantId");


--
-- Name: user_tenants_userId_tenantId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_tenants_userId_tenantId_key" ON public.user_tenants USING btree ("userId", "tenantId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: workflow_executions_entityType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workflow_executions_entityType_idx" ON public.workflow_executions USING btree ("entityType");


--
-- Name: workflow_executions_workflowId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workflow_executions_workflowId_idx" ON public.workflow_executions USING btree ("workflowId");


--
-- Name: workflows_tenantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workflows_tenantId_idx" ON public.workflows USING btree ("tenantId");


--
-- Name: workflows_trigger_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workflows_trigger_idx ON public.workflows USING btree (trigger);


--
-- Name: activities activities_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT "activities_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activities activities_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT "activities_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: activities activities_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT "activities_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: activities activities_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT "activities_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking_slots booking_slots_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_slots
    ADD CONSTRAINT "booking_slots_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking_slots booking_slots_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_slots
    ADD CONSTRAINT "booking_slots_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bookings bookings_bookingSlotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT "bookings_bookingSlotId_fkey" FOREIGN KEY ("bookingSlotId") REFERENCES public.booking_slots(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bookings bookings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT "bookings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bookings bookings_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT "bookings_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: calendar_events calendar_events_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT "calendar_events_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: calendar_events calendar_events_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT "calendar_events_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: calendar_events calendar_events_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT "calendar_events_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: calendar_events calendar_events_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT "calendar_events_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: companies companies_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "companies_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contacts contacts_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT "contacts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: custom_properties custom_properties_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_properties
    ADD CONSTRAINT "custom_properties_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: custom_property_values custom_property_values_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_property_values
    ADD CONSTRAINT "custom_property_values_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.custom_properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deals deals_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: deals deals_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deals deals_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deals deals_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: deals deals_stageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_stageId_fkey" FOREIGN KEY ("stageId") REFERENCES public.pipeline_stages(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: deals deals_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_campaign_recipients email_campaign_recipients_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaign_recipients
    ADD CONSTRAINT "email_campaign_recipients_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public.email_campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_campaigns email_campaigns_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT "email_campaigns_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_clicks email_clicks_emailMessageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_clicks
    ADD CONSTRAINT "email_clicks_emailMessageId_fkey" FOREIGN KEY ("emailMessageId") REFERENCES public.email_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_messages email_messages_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT "email_messages_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: email_messages email_messages_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT "email_messages_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: email_messages email_messages_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT "email_messages_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: email_messages email_messages_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT "email_messages_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_messages email_messages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT "email_messages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: email_opens email_opens_emailMessageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_opens
    ADD CONSTRAINT "email_opens_emailMessageId_fkey" FOREIGN KEY ("emailMessageId") REFERENCES public.email_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_sequences email_sequences_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sequences
    ADD CONSTRAINT "email_sequences_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: email_sequences email_sequences_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sequences
    ADD CONSTRAINT "email_sequences_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_templates email_templates_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT "email_templates_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: email_templates email_templates_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT "email_templates_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_form_submissions lead_form_submissions_formId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_form_submissions
    ADD CONSTRAINT "lead_form_submissions_formId_fkey" FOREIGN KEY ("formId") REFERENCES public.lead_forms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_forms lead_forms_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_forms
    ADD CONSTRAINT "lead_forms_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_score_rules lead_score_rules_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_score_rules
    ADD CONSTRAINT "lead_score_rules_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pipeline_stages pipeline_stages_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pipeline_stages
    ADD CONSTRAINT "pipeline_stages_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_columns project_columns_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_columns
    ADD CONSTRAINT "project_columns_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_tasks project_tasks_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT "project_tasks_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: project_tasks project_tasks_columnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT "project_tasks_columnId_fkey" FOREIGN KEY ("columnId") REFERENCES public.project_columns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_tasks project_tasks_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT "project_tasks_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: project_tasks project_tasks_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT "project_tasks_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: projects projects_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quote_line_items quote_line_items_quoteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_line_items
    ADD CONSTRAINT "quote_line_items_quoteId_fkey" FOREIGN KEY ("quoteId") REFERENCES public.quotes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quotes quotes_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT "quotes_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quotes quotes_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT "quotes_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sequence_enrollment_steps sequence_enrollment_steps_enrollmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequence_enrollment_steps
    ADD CONSTRAINT "sequence_enrollment_steps_enrollmentId_fkey" FOREIGN KEY ("enrollmentId") REFERENCES public.sequence_enrollments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sequence_enrollment_steps sequence_enrollment_steps_stepId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequence_enrollment_steps
    ADD CONSTRAINT "sequence_enrollment_steps_stepId_fkey" FOREIGN KEY ("stepId") REFERENCES public.sequence_steps(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sequence_enrollments sequence_enrollments_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequence_enrollments
    ADD CONSTRAINT "sequence_enrollments_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sequence_enrollments sequence_enrollments_sequenceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequence_enrollments
    ADD CONSTRAINT "sequence_enrollments_sequenceId_fkey" FOREIGN KEY ("sequenceId") REFERENCES public.email_sequences(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sequence_steps sequence_steps_sequenceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequence_steps
    ADD CONSTRAINT "sequence_steps_sequenceId_fkey" FOREIGN KEY ("sequenceId") REFERENCES public.email_sequences(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sequence_steps sequence_steps_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequence_steps
    ADD CONSTRAINT "sequence_steps_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.email_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sms_messages sms_messages_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_messages
    ADD CONSTRAINT "sms_messages_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subtasks subtasks_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT "subtasks_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subtasks subtasks_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT "subtasks_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.project_tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: task_comments task_comments_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT "task_comments_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.project_tasks(id) ON DELETE CASCADE;


--
-- Name: task_comments task_comments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT "task_comments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: tasks tasks_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tasks tasks_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tenant_settings tenant_settings_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT "tenant_settings_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_tenants user_tenants_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT "user_tenants_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_tenants user_tenants_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT "user_tenants_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workflow_executions workflow_executions_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT "workflow_executions_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public.workflows(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workflows workflows_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT "workflows_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: workflows workflows_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT "workflows_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict cD93ZOM2yOJv4a66JlQvCLoqTahOKaZXFh2ih9bTVB5XZJxwz5v9DIUf4UlDoup

